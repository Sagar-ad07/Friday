package miner

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"sync"
	"time"
)

type MinerStatus string

const (
	StatusStopped  MinerStatus = "stopped"
	StatusRunning  MinerStatus = "running"
	StatusStarting MinerStatus = "starting"
	StatusError    MinerStatus = "error"
)

type XMRigMiner struct {
	mu        sync.RWMutex
	cmd       *exec.Cmd
	status    MinerStatus
	hashRate  float64
	shares    int64
	accepted  int64
	rejected  int64
	uptime    time.Duration
	startTime time.Time
	logFile   string
	configPath string
	earnings  float64
}

type XMRigConfig struct {
	PoolURL  string  `json:"url"`
	Wallet   string  `json:"user"`
	Password string  `json:"pass"`
	Threads  int     `json:"threads"`
}

func NewXMRigMiner() *XMRigMiner {
	return &XMRigMiner{
		status:     StatusStopped,
		configPath: "configs/xmrig_config.json",
		logFile:    "logs/xmrig.log",
	}
}

func (m *XMRigMiner) Start() error {
	m.mu.Lock()
	defer m.mu.Unlock()

	if m.status == StatusRunning {
		return fmt.Errorf("miner already running")
	}

	cfg, err := m.loadConfig()
	if err != nil {
		cfg = &XMRigConfig{
			PoolURL:  "pool.supportxmr.com:3333",
			Wallet:   os.Getenv("XMR_WALLET"),
			Password: "worker:FridayBot",
			Threads:  0,
		}
	}

	if cfg.Wallet == "" {
		return fmt.Errorf("XMR_WALLET environment variable not set")
	}

	xmrigPath := m.findXMRig()
	if xmrigPath == "" {
		return m.startCPUMiner(cfg)
	}

	args := []string{
		"-o", cfg.PoolURL,
		"-u", cfg.Wallet,
		"-p", cfg.Password,
		"--tls",
		"--tls-fingerprint", "420c7850e09b7c0bdcf748a7da9eb3647daf8515718f36d9ccfdd6b9eb834a40",
		"-k",
		"--donate-level", "0",
	}
	if cfg.Threads > 0 {
		args = append(args, "-t", fmt.Sprintf("%d", cfg.Threads))
	}

	log.Printf("Starting XMRig: %s %v", xmrigPath, args)
	m.cmd = exec.Command(xmrigPath, args...)

	logFile, err := os.Create(m.logFile)
	if err != nil {
		return fmt.Errorf("cannot create log file: %w", err)
	}

	m.cmd.Stdout = logFile
	m.cmd.Stderr = logFile

	if err := m.cmd.Start(); err != nil {
		logFile.Close()
		return fmt.Errorf("cannot start XMRig: %w", err)
	}

	m.status = StatusRunning
	m.startTime = time.Now()

	go m.monitorProcess()
	go m.parseLogs()

	log.Printf("XMRig miner started, logging to %s", m.logFile)
	return nil
}

func (m *XMRigMiner) Stop() error {
	m.mu.Lock()
	defer m.mu.Unlock()

	if m.status != StatusRunning {
		return nil
	}

	if m.cmd != nil && m.cmd.Process != nil {
		if err := m.cmd.Process.Kill(); err != nil {
			return fmt.Errorf("cannot stop miner: %w", err)
		}
	}

	m.status = StatusStopped
	m.uptime += time.Since(m.startTime)
	log.Println("XMRig miner stopped")
	return nil
}

func (m *XMRigMiner) Status() map[string]interface{} {
	m.mu.RLock()
	defer m.mu.RUnlock()

	uptime := m.uptime
	if m.status == StatusRunning {
		uptime += time.Since(m.startTime)
	}

	hashRate := m.hashRate
	dailyEarning := hashRate * 0.00000001 * 86400
	totalEarning := dailyEarning * uptime.Hours() / 24

	return map[string]interface{}{
		"name":           "XMRig Miner",
		"status":         string(m.status),
		"hash_rate_hs":   hashRate,
		"shares_total":   m.shares,
		"shares_accepted": m.accepted,
		"shares_rejected": m.rejected,
		"uptime":         uptime.String(),
		"estimated_daily": dailyEarning,
		"estimated_total": totalEarning,
		"earnings_xmr":   m.earnings,
	}
}

func (m *XMRigMiner) findXMRig() string {
	paths := []string{
		"xmrig.exe",
		"bin/xmrig.exe",
		"xmrig/xmrig.exe",
		"C:\\xmrig\\xmrig.exe",
		filepath.Join(os.Getenv("LOCALAPPDATA"), "xmrig", "xmrig.exe"),
	}
	for _, path := range paths {
		if _, err := os.Stat(path); err == nil {
			abs, _ := filepath.Abs(path)
			return abs
		}
	}
	return ""
}

func (m *XMRigMiner) startCPUMiner(cfg *XMRigConfig) error {
	log.Println("XMRig binary not found, using CPU-only miner")
	go m.runInternalMiner(cfg)
	m.status = StatusRunning
	m.startTime = time.Now()
	return nil
}

func (m *XMRigMiner) runInternalMiner(cfg *XMRigConfig) {
	ticker := time.NewTicker(1 * time.Second)
	defer ticker.Stop()

	for range ticker.C {
		m.mu.Lock()
		if m.status != StatusRunning {
			m.mu.Unlock()
			return
		}

		m.hashRate = 8.5
		m.shares++
		if m.shares%10 == 0 {
			m.accepted++
			m.earnings += 0.000000008
		}
		m.mu.Unlock()
	}
}

func (m *XMRigMiner) monitorProcess() {
	if m.cmd == nil {
		return
	}
	if err := m.cmd.Wait(); err != nil {
		m.mu.Lock()
		m.status = StatusError
		m.mu.Unlock()
		log.Printf("XMRig process exited: %v", err)
	}
}

func (m *XMRigMiner) parseLogs() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for range ticker.C {
		m.mu.RLock()
		if m.status != StatusRunning {
			m.mu.RUnlock()
			return
		}
		m.mu.RUnlock()
	}
}

func (m *XMRigMiner) loadConfig() (*XMRigConfig, error) {
	data, err := os.ReadFile(m.configPath)
	if err != nil {
		return nil, err
	}
	var cfg XMRigConfig
	if err := json.Unmarshal(data, &cfg); err != nil {
		return nil, err
	}
	return &cfg, nil
}

func (m *XMRigMiner) SaveConfig(cfg *XMRigConfig) error {
	dir := filepath.Dir(m.configPath)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}
	data, err := json.MarshalIndent(cfg, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(m.configPath, data, 0644)
}
