package friday

import (
	"context"
	"errors"
	"sync"
	"time"
)

var (
	ErrCircuitOpen     = errors.New("circuit breaker open")
	ErrRateLimited     = errors.New("rate limit exceeded")
	ErrAllProvidersFail = errors.New("all providers failed")
	ErrTimeout         = errors.New("operation timeout")
)

type CircuitBreaker struct {
	mu           sync.RWMutex
	failures     map[string]int32
	openUntil    map[string]int64 // unix nano
	threshold    int32
	cooldown     time.Duration
	halfOpenMax  int32
	halfOpenReq  map[string]int32
}

func NewCircuitBreaker(threshold int, cooldown time.Duration) *CircuitBreaker {
	return &CircuitBreaker{
		failures:    make(map[string]int32),
		openUntil:   make(map[string]int64),
		threshold:   int32(threshold),
		cooldown:    cooldown,
		halfOpenMax: 3,
		halfOpenReq: make(map[string]int32),
	}
}

func (cb *CircuitBreaker) IsOpen(key string) bool {
	cb.mu.RLock()
	defer cb.mu.RUnlock()

	until, ok := cb.openUntil[key]
	if !ok || until == 0 {
		return false
	}
	now := time.Now().UnixNano()
	if now >= until {
		// transition to half-open
		return false
	}
	return true
}

func (cb *CircuitBreaker) RecordSuccess(key string) {
	cb.mu.Lock()
	defer cb.mu.Unlock()

	cb.failures[key] = 0
	cb.openUntil[key] = 0
	delete(cb.halfOpenReq, key)
}

func (cb *CircuitBreaker) RecordFailure(key string) {
	cb.mu.Lock()
	defer cb.mu.Unlock()

	current := cb.failures[key]
	newVal := current + 1
	cb.failures[key] = newVal
	if newVal >= cb.threshold {
		cb.openUntil[key] = time.Now().Add(cb.cooldown).UnixNano()
		delete(cb.halfOpenReq, key)
	}
}

func (cb *CircuitBreaker) TryAcquireHalfOpen(key string) bool {
	cb.mu.Lock()
	defer cb.mu.Unlock()

	if cb.openUntil[key] == 0 {
		return true // not open
	}

	if time.Now().UnixNano() < cb.openUntil[key] {
		return false // still in cooldown
	}

	// half-open: allow limited requests
	current := cb.halfOpenReq[key]
	if current >= cb.halfOpenMax {
		return false
	}
	cb.halfOpenReq[key] = current + 1
	return true
}

func (cb *CircuitBreaker) ReleaseHalfOpen(key string, success bool) {
	cb.mu.Lock()
	defer cb.mu.Unlock()

	if success {
		cb.failures[key] = 0
		cb.openUntil[key] = 0
		delete(cb.halfOpenReq, key)
	} else {
		cb.openUntil[key] = time.Now().Add(cb.cooldown).UnixNano()
		delete(cb.halfOpenReq, key)
	}
}

type TokenBucket struct {
	mu       sync.Mutex
	tokens   float64
	capacity float64
	rate     float64 // tokens per second
	last     time.Time
}

func NewTokenBucket(capacity, rate int) *TokenBucket {
	return &TokenBucket{
		tokens:   float64(capacity),
		capacity: float64(capacity),
		rate:     float64(rate),
		last:     time.Now(),
	}
}

func (tb *TokenBucket) Allow() bool {
	tb.mu.Lock()
	defer tb.mu.Unlock()

	now := time.Now()
	elapsed := now.Sub(tb.last).Seconds()
	tb.tokens = min(tb.capacity, tb.tokens+elapsed*tb.rate)
	tb.last = now

	if tb.tokens >= 1 {
		tb.tokens--
		return true
	}
	return false
}

func (tb *TokenBucket) Wait(ctx context.Context) error {
	for {
		if tb.Allow() {
			return nil
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(10 * time.Millisecond):
		}
	}
}

type RateLimiter struct {
	mu      sync.RWMutex
	buckets map[string]*TokenBucket
	rate    int
	burst   int
}

func NewRateLimiter(rate, burst int) *RateLimiter {
	return &RateLimiter{
		buckets: make(map[string]*TokenBucket),
		rate:    rate,
		burst:   burst,
	}
}

func (rl *RateLimiter) getBucket(key string) *TokenBucket {
	rl.mu.RLock()
	b, ok := rl.buckets[key]
	rl.mu.RUnlock()

	if ok {
		return b
	}

	rl.mu.Lock()
	defer rl.mu.Unlock()
	if b, ok = rl.buckets[key]; ok {
		return b
	}
	b = NewTokenBucket(rl.burst, rl.rate)
	rl.buckets[key] = b
	return b
}

func (rl *RateLimiter) Allow(key string) bool {
	return rl.getBucket(key).Allow()
}

func (rl *RateLimiter) Wait(ctx context.Context, key string) error {
	return rl.getBucket(key).Wait(ctx)
}

type HedgeExecutor struct {
	providers []string
	timeouts  map[string]time.Duration
	client    HedgeClient
}

type HedgeClient interface {
	Call(ctx context.Context, provider string, payload []byte) ([]byte, error)
}

func NewHedgeExecutor(providers []string, defaultTimeout time.Duration, client HedgeClient) *HedgeExecutor {
	timeouts := make(map[string]time.Duration)
	for _, p := range providers {
		timeouts[p] = defaultTimeout
	}
	return &HedgeExecutor{
		providers: providers,
		timeouts:  timeouts,
		client:    client,
	}
}

func (he *HedgeExecutor) Execute(ctx context.Context, payload []byte) ([]byte, string, error) {
	type result struct {
		data     []byte
		provider string
		err      error
	}

	ch := make(chan result, len(he.providers))

	for _, provider := range he.providers {
		p := provider
		go func() {
			ctxTimeout, cancel := context.WithTimeout(ctx, he.timeouts[p])
			defer cancel()
			data, err := he.client.Call(ctxTimeout, p, payload)
			ch <- result{data: data, provider: p, err: err}
		}()
	}

	var lastErr error
	for range he.providers {
		select {
		case r := <-ch:
			if r.err == nil {
				return r.data, r.provider, nil
			}
			lastErr = r.err
		case <-ctx.Done():
			return nil, "", ctx.Err()
		}
	}

	return nil, "", lastErr
}

type SafeExecutor struct {
	cb       *CircuitBreaker
	rl       *RateLimiter
	hedge    *HedgeExecutor
	fallback func() ([]byte, error)
}

func NewSafeExecutor(cb *CircuitBreaker, rl *RateLimiter, hedge *HedgeExecutor, fallback func() ([]byte, error)) *SafeExecutor {
	return &SafeExecutor{cb: cb, rl: rl, hedge: hedge, fallback: fallback}
}

func (se *SafeExecutor) Execute(ctx context.Context, provider string, payload []byte) ([]byte, error) {
	// Check circuit breaker
	if se.cb.IsOpen(provider) {
		if se.hedge != nil {
			data, prov, err := se.hedge.Execute(ctx, payload)
			if err == nil {
				se.cb.RecordSuccess(prov)
				return data, nil
			}
		}
		if se.fallback != nil {
			return se.fallback()
		}
		return nil, ErrCircuitOpen
	}

	// Check rate limiter
	if !se.rl.Allow(provider) {
		return nil, ErrRateLimited
	}

	// Try primary
	data, err := se.hedge.client.Call(ctx, provider, payload)
	if err == nil {
		se.cb.RecordSuccess(provider)
		return data, nil
	}

	se.cb.RecordFailure(provider)

	// Hedge fallback
	if se.hedge != nil {
		data, prov, err := se.hedge.Execute(ctx, payload)
		if err == nil {
			se.cb.RecordSuccess(prov)
			return data, nil
		}
	}

	// Final fallback
	if se.fallback != nil {
		return se.fallback()
	}

	return nil, ErrAllProvidersFail
}

