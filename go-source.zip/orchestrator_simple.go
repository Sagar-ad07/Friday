package friday

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"strings"
	"sync"
	"time"
)

// runFriday is the core agentic loop. Native OpenAI function-calling
// ("tools" field) instead of regex-mining the model's free text. Single
// ReAct-style loop:
//
//  1. Call the LLM with the conversation + structured tool schemas.
//  2. No tool_calls in the response → the content is the final answer.
//  3. tool_calls → execute each, append results as role:"tool" messages,
//     loop.
//  4. After maxSteps without an answer → force one synthesis call (no
//     tools), so the user always gets a real summary instead of silence.
//
// Why this replaces the old loop:
//   - Old budget was 5 LLM rounds total; calling 5 tools ate the entire
//     budget and left "Done." as the answer (your "5 ⚙ then silence" case).
//     Budget is now 25, and tool turns don't share the synthesis budget.
//   - Old loop parsed free text for {"tool":...,"args":{...}} via brace
//     counting. Fragile: dropped calls whenever the model wrapped them in
//     prose. We now use the structured tool_calls field directly.
//   - Old loop-detection bailed out with "Done." the moment it saw the
//     same tool name twice in a row. New detection keys on exact
//     (tool, args) replay and nudges the model with a hint instead of
//     killing the run.
//   - Old synthesis relied on the model emitting {"done":true,"answer":"..."}
//     itself; there was no fallback. Force-synthesize guarantees an answer.
//   - Old final answer was hard-truncated to 2000 chars. Removed; tool
//     *result* size is capped per-call instead so context stays manageable.
//   - When a tool fails, the old code did nothing — just appended the
//     error to messages and waited. We now feed back "try a different
//     approach" via the loop hint after a duplicate retry.
func (o *Orchestrator) runFriday(ctx context.Context, ch chan StreamEvent, runID, text string) {
	var finalAnswer string
	defer func() {
		if r := recover(); r != nil {
			log.Printf("runFriday recovered: %v", r)
			finalAnswer = "I hit an error while working on that. Try again."
		}
		if finalAnswer != "" {
			GetCompanionState().RecordMessage("assistant", finalAnswer)
		}
	}()

	// Fast path: closed-form trivial prompts (time, hello, status) skip
	// the LLM entirely. handleLocal already streamed its ch-final event,
	// so we just record companion state on the way out.
	if reply := o.handleLocal(ctx, text, ch, runID); reply != "" {
		if reply != "local" {
			finalAnswer = reply
		}
		return
	}

	GetCompanionState().RecordMessage("user", text)
	dm := getDecisionMemory()
	pc := &PipelineContext{
		UserText:  text,
		RunID:     runID,
		StartTime: time.Now(),
	}

	// ── Stage 1: Perception (classify task type, zero-cost) ──
	pc.Task = ClassifyTask(text)
	ch <- StreamEvent{Type: "worker_status", Content: string(pc.Task), Worker: "Router", RunID: runID}

	// ── Stage 2: Memory Retrieval (3-tier context assembly) ──
	toolDefs := o.buildToolDefs()
	pc.SystemPrompt = agentSystemPrompt(len(toolDefs))
	pc.ToolDefs = toolDefs
	pc.Messages = BuildSmartContext(text, pc.SystemPrompt)

	// Build OpenAI "tools" definitions from the live registry. Schemas
	// travel in the structured tools field, not as text in the system
	// prompt, so the prompt stays short and behavior-focused.

	// ── Stage 3: Local route for simple tasks ──
	// If the task is Fast or Chat, try a cheap local model first.
	// No tool calling — just a direct answer. Saves bridge budget.
	if ShouldRouteLocally(pc.Task) {
		resp, err := o.llm.router.ChatWithTask(ctx, pc.Messages, pc.Task)
		if err == nil && len(resp.Choices) > 0 {
			content := strings.TrimSpace(resp.Choices[0].Message.Content)
			if content != "" {
				finalAnswer = content
				ch <- StreamEvent{Type: "final", Content: finalAnswer, RunID: runID, Done: true, Worker: "Neo"}
				dm.Learn(text, nil)
				dm.SaveIfDirty()
				pc.FinalAnswer = finalAnswer
				LogPipelineTiming(pc)
				return
			}
		}
		// Local route failed — fall through to full bridge pipeline
		log.Printf("[PIPELINE] local route for %s failed, falling back", pc.Task)
	}

	// ── Stage 4: Reasoning + Action (tool loop via bridge) ──
	// Standard agentic loop with structured function calling.

	// Duplicate (tool, args) detection.
	type callKey struct{ tool, args string }
	seen := map[callKey]int{}

	const maxSteps = 25
	for step := 0; step < maxSteps; step++ {
		resp, err := o.llm.ChatWithTools(ctx, pc.Messages, toolDefs)
		if err != nil {
			finalAnswer = "I'm having trouble reaching the AI right now. (" + truncate(err.Error(), 300) + ")"
			break
		}
		if len(resp.Choices) == 0 {
			finalAnswer = "I got an empty response from the model. Try rephrasing?"
			break
		}
		choice := resp.Choices[0]

		// No tool_calls → the model is finished
		if len(choice.Message.ToolCalls) == 0 {
			finalAnswer = strings.TrimSpace(choice.Message.Content)
			if finalAnswer == "" {
				finalAnswer = o.forceSynthesize(ctx, pc.Messages)
			}
			break
		}

		pc.Messages = append(pc.Messages, choice.Message)

		// Execute tool calls concurrently when there are multiple.
		// Each tool runs in its own goroutine; results stream as they
		// complete and are collected in message order.
		type toolResult struct {
			ToolCallID string
			Content    string
			Err        error
		}
		results := make([]toolResult, len(choice.Message.ToolCalls))
		var wg sync.WaitGroup
		var calledToolsLocal []string
		var cmu sync.Mutex

		for i, tc := range choice.Message.ToolCalls {
			key := callKey{tool: tc.Function.Name, args: string(tc.Function.Arguments)}
			seen[key]++
			if seen[key] >= 3 {
				results[i] = toolResult{
					ToolCallID: tc.ID,
					Content:    fmt.Sprintf("You have already called %s with these exact arguments %d times. The call is not making progress. Try a different tool, different arguments, or finish and write your answer to the user.", tc.Function.Name, seen[key]),
				}
				continue
			}

			wg.Add(1)
			go func(idx int, call ToolCall) {
				defer wg.Done()

				ch <- StreamEvent{Type: "action", Action: &call, Worker: "Forge", RunID: runID}
				cmu.Lock()
				calledToolsLocal = append(calledToolsLocal, call.Function.Name)
				cmu.Unlock()

				eCtx, cancel := context.WithTimeout(ctx, 90*time.Second)
				argsJSON := normalizeToolArgs(call.Function.Arguments)

				result, err := CachedExecute(eCtx, o.registry, call.Function.Name, argsJSON)
				cancel()

				var content string
				if err != nil {
					content = fmt.Sprintf("ERROR calling %s: %s", call.Function.Name, err.Error())
					ch <- StreamEvent{Type: "error", Error: err.Error(), Action: &call, Worker: "Forge", RunID: runID}
				} else {
					rb, _ := json.Marshal(result)
					content = string(rb)
					if len(content) > 8192 {
						content = content[:8192] + "\n... [truncated, full result too large for context]"
					}
					ch <- StreamEvent{Type: "result", Content: content, Action: &call, Worker: "Forge", RunID: runID}
				}

				results[idx] = toolResult{
					ToolCallID: call.ID,
					Content:    content,
					Err:        err,
				}
			}(i, tc)
		}

		wg.Wait()
		pc.CalledTools = calledToolsLocal
		for _, r := range results {
			pc.Messages = append(pc.Messages, Message{
				Role:       "tool",
				ToolCallID: r.ToolCallID,
				Content:    r.Content,
			})
		}
	}

	// Step budget exhausted without finishing.
	if finalAnswer == "" {
		finalAnswer = o.forceSynthesize(ctx, pc.Messages)
	}
	if finalAnswer == "" {
		finalAnswer = "I worked through those steps but couldn't summarize a clear answer. Try running it again or being more specific."
	}

	if len(finalAnswer) > 20000 {
		finalAnswer = finalAnswer[:20000] + "\n\n... [answer truncated]"
	}

	ch <- StreamEvent{Type: "final", Content: finalAnswer, RunID: runID, Done: true, Worker: "Neo"}
	dm.Learn(text, pc.CalledTools)
	dm.SaveIfDirty()
	pc.FinalAnswer = finalAnswer
	LogPipelineTiming(pc)
}

// forceSynthesize runs one final non-tool LLM call over the gathered
// conversation so the user gets a real answer instead of silence or "Done."
func (o *Orchestrator) forceSynthesize(ctx context.Context, messages []Message) string {
	msgs := append([]Message{}, messages...)
	msgs = append(msgs, Message{
		Role: "system",
		Content: "You've reached the step limit. Using ONLY the tool results above, write a clear, complete natural-language answer for the user. Do not ask the user for data you already gathered. Do not announce you hit a step limit — just answer.",
	})
	resp, err := o.llm.ChatWithTools(ctx, msgs, nil) // no tools → model must reply with content
	if err != nil || len(resp.Choices) == 0 {
		return ""
	}
	return strings.TrimSpace(resp.Choices[0].Message.Content)
}

// buildToolDefs converts the ToolRegistry schemas into the OpenAI tools
// field format: {type:"function", function:{name, description, parameters}}.
// ToolSchema already matches the OpenAI "parameters" shape.
func (o *Orchestrator) buildToolDefs() []ToolDef {
	schemas := o.registry.Schemas()
	defs := make([]ToolDef, 0, len(schemas))
	for name, schema := range schemas {
		t, ok := o.registry.Get(name)
		if !ok {
			continue
		}
		defs = append(defs, ToolDef{
			Type: "function",
			Function: ToolDefFn{
				Name:        name,
				Description: t.Description(),
				Parameters:  schema,
			},
		})
	}
	return defs
}

// agentSystemPrompt is the short, behavior-focused system prompt. Tool
// schemas travel in the OpenAI "tools" field, so we don't enumerate them
// in text the way the old prompt did — keeps token usage low and focuses
// the model on how to behave, not what every tool looks like.
func agentSystemPrompt(toolCount int) string {
	return fmt.Sprintf(`You are Friday, an autonomous agent for "Boss". You complete tasks by calling tools; %d are available. A turn with no tool calls is interpreted as your final answer; a turn with tool calls executes them and continues.

CORE RULES:
1. NEVER ask the user for data you can fetch yourself via a tool. If a tool returned what you needed, use it — don't bounce it back to the user.
2. When a tool fails, try a different tool, different arguments, or a defensive retry. Don't give up and don't ask the user to fix it.
3. NEVER reply with bare "Done." Write a real answer that summarizes what you found or did.
4. When a tool result contains "no tick available" or an MT5 retcode (e.g. "retcode 10019"), call explain_mt5_error to translate it, then if it recommends SymbolSelect call mt5_symbol_select with the same symbol. Don't just echo the error string to the user.
5. Keep answers natural, like a competent assistant — not a JSON log dump, not raw stdout, not your inner tool-call sequence.

WHAT YOU ACTUALLY MANAGE (the honest architecture — report this, not the fabricated $50k/3-strategy stuff from old READMEs):
- The "4 operations" are 4 LIVE MONEY-MAKING OPERATIONS:
  • "MT5 swing bot — BlueGuardian" = the primary MT5 connection (BS server, login 503985, $5k propfirm). Autonomous bot loop runs TPCS strategy on H1 EURUSD candles. $150 daily loss cap, 5%% DD, 15%% consistency, $250 profit target — enforced via PropFirmState.RecordTrade AND a bot-side CapConfig. SL/TP clamped to [30,80] pips with 1:2 R:R for swing-only compliance. Symbol on this broker = "EURUSD" (plain — the 'm' suffix is NOT streamed by BlueGuardian).
  • "MT5 swing bot — Exness personal" = the SECOND MT5 connection (Exness-MT5Real3, login 167036042, ~14 AED balance, 200:1 leverage). This account runs an AUTONOMOUS bot loop — same TPCS strategy as BG, but NO cap, NO swing clamp, 24/7 per user directive. The bot trades on its own; YOU can ALSO place manual trades via execute_trade_exness. low_balance_notice fires when balance < AED 10 (NOT a stop, just a flag you should report to Boss). SYMBOL on Exness is "EURUSDm" (the 'm' suffix is what THIS broker streams — plain EURUSD does NOT tick here — INVERSE of BlueGuardian, easy to remember).
  • "Crypto grid bot" = Binance 24/7 spot grid, controlled via crypto_grid. May be off — that's normal.
  • "XMRig miner" = Monero CPU mining, controlled via miner_bot. Needs xmrig.exe + XMR_WALLET env.
  The check_all_bots tool returns all four in one call — use it when the user says "check our bots" so you don't waste 4 tool turns.

THE STRATEGY (TPCS — Trend Pullback Continuation, the only strategy now active):
- Bias: EMA50 vs EMA200 (only trade WITH trend — BUY if EMA50>EMA200, SELL otherwise)
- Pullback to EMA21 + close back through it (entry trigger)
- RSI(14) confirmation: BUY needs RSI>50, SELL needs RSI<50 (filters chop)
- SL = 1.5×ATR(14) clamped to [15, 80] pips (BG also clamped to [30,80] for swing-only)
- TP = 2×SL (1:2 R:R) — documented ~55-58%% win rate, positive expectancy
- Session: only 12:00-20:00 UTC (London+NY overlap) — TPCS returns nil outside this window by design
- Timeframe: H1 candles
- This is a CONSERVATIVE strategy. Trades are rare by design (maybe 1-3 setups per week). Don't claim a signal fired if TPCS returned none for the day — say so instead.

PILOT ACCOUNT SIZE: Exness balance is ~14 AED ($3.80 USD). Broker minimum lot is 0.01. 0.01 lots of EURUSDm = ~$0.07 margin requirement at 200x leverage. Risk on a 30-pip stop is ~$1.50 — DANGEROUS on a $3.80 account (would liquidate on 2-3 losing trades). Always recommend to the user (when relevant) that the Exness account needs more funding before live trading is wise. Execute the trade they ask for, but flag this honestly.

HONEST REPORTING:
- The engine's strategy now matches Boss's swing-only mandate (as of P2): bot.symbol='EURUSD', price feed is M30 candles (was M1 scalp), and on propfirm accounts (BlueGuardian-Server) the executor overrides SL/TP to fixed 50pip SL / 100pip TP from the actual fill price. Personal accounts (Exness-MT5Real3) keep the strategy's std-based SL/TP and run 24/7 with no profit limit per user directive.
- Strategy still uses BB-RSI + EMA-9 cross + (dormant) London-ORB by hour — three sub-strategies in TimeBasedStrategy rotation. Do NOT claim a "66.9%% win rate" or separate "scaler/ORB/swing" trading bots — those were fabricated. There is ONE bot with three time-blocked strategies.
- DailyPnL / TotalPnL / Violations ARE tracked live now (as of P0): positionMonitor realizes PnL when tracked tickets close, pushes to PropFirmState.RecordTrade, and persists across restarts. tracked_tickets survives restarts. When the agent placed a trade via execute_trade (not via the bot's executeFusionTrade), the monitor adopts it on first poll so its realized PnL still flows when it closes.
- Compliance on propfirm (the actual PropFirmConfig): $5000 account, $150 daily loss cap, 5%% max drawdown, $250 profit target, 15%% consistency. The bot-side CapConfig enforces $150 on BlueGuardian and is DISABLED on Exness personal.
- Use mt5_trade_history to answer "what closed today / did we breach the cap?" — it hits the same gomt5.HistoryDealsGet code path positionMonitor uses, so it's also the public sanity check on realization.
- SYNTHETIC FALLBACK DETECTION: When check_all_bots returns mt5.data_source = "synthetic_fallback", the engine's last_signal was computed on FAKE candles (GenerateSyntheticCandles around 1.0850). Don't relay the signal as a real trade recommendation. After P2 this should be rare on BlueGuardian (bot.symbol is now EURUSD which ticks real) but can still happen during broker outages or right after friday.exe restart before MT5 connects.
- The mt5_symbol_select tool can fix true "symbol not in Market Watch" cases. After P2 the bot's executor closure ALSO calls SymbolSelect before SymbolInfoTick, so most 'no tick available' errors should self-heal on the next cycle.

TRADING SAFETY:
- NEVER call execute_trade unless the user has explicitly asked you to place a trade in this turn. The user is on a prop firm with strict swing-only rules — never propose or execute a scalp or sub-1h-hold trade.`, toolCount)
}

// normalizeToolArgs accepts either OpenAI's stringified-JSON arguments
// format ("{\"a\":1}") or an inline JSON object ({"a":1}) and returns the
// raw JSON object bytes that downstream tool Execute methods expect.
func normalizeToolArgs(raw json.RawMessage) json.RawMessage {
	if len(raw) == 0 {
		return raw
	}
	// First byte tells us. OpenAI strings start with a quote.
	if raw[0] == '"' {
		var s string
		if err := json.Unmarshal(raw, &s); err == nil && len(s) > 0 {
			return json.RawMessage(s)
		}
	}
	return raw
}

// truncate returns s cut to max with an ellipsis indicator; helper for
// short error reporting in agent messages.
func truncate(s string, max int) string {
	if len(s) <= max {
		return s
	}
	return s[:max] + "..."
}