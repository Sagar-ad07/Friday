package pipeline

import (
	"sync"
	"time"
)

// FeedSource represents a market data feed with latency characteristics
type FeedSource struct {
	Name      string
	Endpoint  string
	Weight    float64
	Latency   time.Duration
	LastPrice float64
	Timestamp time.Time
	Mutex     sync.RWMutex
}

// UltraLowLatencyFeed aggregates multiple market data sources
type UltraLowLatencyFeed struct {
	sources []FeedSource
	mutex   sync.RWMutex
	stopCh  chan struct{}
}

// NewUltraLowLatencyFeed creates a new ultra-low latency feed aggregator
func NewUltraLowLatencyFeed() *UltraLowLatencyFeed {
	return &UltraLowLatencyFeed{
		stopCh: make(chan struct{}),
		sources: []FeedSource{
			{
				Name:     "MT5",
				Endpoint: "ws://localhost:4438",
				Weight:   0.5,
				Latency:  5 * time.Millisecond,
			},
			{
				Name:     "AlphaVantage",
				Endpoint: "https://www.alphavantage.co/query",
				Weight:   0.2,
				Latency:  120 * time.Millisecond,
			},
			{
				Name:     "Binance",
				Endpoint: "wss://stream.binance.com:9443/ws",
				Weight:   0.3,
				Latency:  8 * time.Millisecond,
			},
		},
	}
}

// GetConsensus returns the weighted average price from all active feeds
func (f *UltraLowLatencyFeed) GetConsensus() float64 {
	f.mutex.RLock()
	defer f.mutex.RUnlock()

	var weightedSum, totalWeight float64
	now := time.Now()

	for i := range f.sources {
		f.sources[i].Mutex.RLock()
		if now.Sub(f.sources[i].Timestamp) < 100*time.Millisecond {
			weightedSum += f.sources[i].LastPrice * f.sources[i].Weight
			totalWeight += f.sources[i].Weight
		}
		f.sources[i].Mutex.RUnlock()
	}

	if totalWeight == 0 {
		return 0 // No fresh data available
	}

	return weightedSum / totalWeight
}

// GetLatency returns the current latency profile
func (f *UltraLowLatencyFeed) GetLatency() map[string]time.Duration {
	f.mutex.RLock()
	defer f.mutex.RUnlock()

	latencies := make(map[string]time.Duration)
	for i := range f.sources {
		latencies[f.sources[i].Name] = f.sources[i].Latency
	}
	return latencies
}

// UpdatePrice updates the price from a specific source
func (f *UltraLowLatencyFeed) UpdatePrice(sourceName string, price float64) {
	f.mutex.Lock()
	defer f.mutex.Unlock()

	for i := range f.sources {
		if f.sources[i].Name == sourceName {
			f.sources[i].Mutex.Lock()
			f.sources[i].LastPrice = price
			f.sources[i].Timestamp = time.Now()
			f.sources[i].Mutex.Unlock()
			break
		}
	}
}

// Start begins the data feed collection
func (f *UltraLowLatencyFeed) Start() {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	if f.stopCh == nil {
		f.stopCh = make(chan struct{})
	}
	for i := range f.sources {
		go f.startFeed(&f.sources[i])
	}
}

// Stop stops all data feed goroutines
func (f *UltraLowLatencyFeed) Stop() {
	f.mutex.Lock()
	defer f.mutex.Unlock()
	select {
	case <-f.stopCh:
		return
	default:
		close(f.stopCh)
		f.stopCh = nil
	}
}

func (f *UltraLowLatencyFeed) startFeed(source *FeedSource) {
	ticker := time.NewTicker(source.Latency / 2)
	defer ticker.Stop()

	// Use a local reference that won't be affected by struct copies
	for {
		select {
		case <-ticker.C:
			price, err := f.fetchPrice(source)
			if err == nil {
				source.Mutex.Lock()
				source.LastPrice = price
				source.Timestamp = time.Now()
				source.Mutex.Unlock()
			}
		case <-f.stopCh:
			return
		}
	}
}

func (f *UltraLowLatencyFeed) fetchPrice(source *FeedSource) (float64, error) {
	// Implementation would connect to the respective feed
	// This is a placeholder for the actual implementation
	return 0, nil
}