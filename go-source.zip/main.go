package main

import (
	"bytes"
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"math/rand"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

const (
	OPENCODE_ENDPOINT = "https://opencode.ai/zen/v1/chat/completions"
	OPENCODE_MODEL    = "deepseek-v4-flash-free"
)

var (
	startTime   = time.Now()
	requests    int64
	errCount    int64
	httpClient  = &http.Client{Timeout: 120 * time.Second}
	maxRetries  = 3
	retryDelays = []time.Duration{1 * time.Second, 3 * time.Second, 10 * time.Second}
)

type Message struct {
	Role    string      `json:"role"`
	Content interface{} `json:"content"`
}

type ChatRequest struct {
	Model       string    `json:"model"`
	Messages    []Message `json:"messages"`
	Stream      bool      `json:"stream"`
	MaxTokens   int       `json:"max_tokens,omitempty"`
	Temperature float64   `json:"temperature,omitempty"`
}

type ChatResponse struct {
	ID      string   `json:"id"`
	Object  string   `json:"object"`
	Created int64    `json:"created"`
	Model   string   `json:"model"`
	Choices []Choice `json:"choices"`
	Usage   Usage    `json:"usage"`
}

type Choice struct {
	Index        int     `json:"index"`
	Message      Message `json:"message"`
	FinishReason string  `json:"finish_reason"`
}

type Usage struct {
	PromptTokens     int `json:"prompt_tokens"`
	CompletionTokens int `json:"completion_tokens"`
	TotalTokens      int `json:"total_tokens"`
}

type Model struct {
	ID      string `json:"id"`
	Object  string `json:"object"`
	Created int64  `json:"created"`
	OwnedBy string `json:"owned_by"`
}

type ModelsResponse struct {
	Object string  `json:"object"`
	Data   []Model `json:"data"`
}

type StatsResponse struct {
	Status        string `json:"status"`
	Uptime        string `json:"uptime"`
	TotalRequests int64  `json:"total_requests"`
	Errors        int64  `json:"errors"`
}

func main() {
	port := getEnv("PORT", "9001")

	if os.Getenv("GIN_MODE") == "" {
		gin.SetMode(gin.ReleaseMode)
	}

	r := gin.New()
	r.Use(gin.Recovery())
	r.Use(cors.New(cors.Config{
		AllowOrigins:     []string{"*"},
		AllowMethods:     []string{"GET", "POST", "OPTIONS"},
		AllowHeaders:     []string{"Content-Type"},
		AllowCredentials: true,
		MaxAge:           12 * time.Hour,
	}))

	r.GET("/health", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "ok", "time": time.Now().Unix()})
	})

	r.GET("/v1/models", func(c *gin.Context) {
		c.JSON(http.StatusOK, ModelsResponse{
			Object: "list",
			Data: []Model{
				{ID: OPENCODE_MODEL, Object: "model", Created: startTime.Unix(), OwnedBy: "opencode"},
			},
		})
	})

	r.POST("/v1/chat/completions", handleChat)
	r.POST("/v1/audio/transcriptions", handleTranscribe)
	r.POST("/v1/audio/speech", handleSpeech)

	r.GET("/stats", func(c *gin.Context) {
		c.JSON(http.StatusOK, StatsResponse{
			Status:        "ok",
			Uptime:        time.Since(startTime).String(),
			TotalRequests: requests,
			Errors:        errCount,
		})
	})

	srv := &http.Server{
		Addr:         ":" + port,
		Handler:      r,
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 300 * time.Second,
		IdleTimeout:  120 * time.Second,
	}

	go func() {
		log.Printf("Friday LLM Bridge running on port %s — brain: deepseek-v4-flash-free (free)", port)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Server error: %v", err)
		}
	}()

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	srv.Shutdown(ctx)
	log.Println("Bridge stopped")
}

func callWithRetry(ctx context.Context, body []byte) (*http.Response, error) {
	var lastErr error
	for i := 0; i < maxRetries; i++ {
		if i > 0 {
			time.Sleep(retryDelays[i-1])
		}
		httpReq, err := http.NewRequestWithContext(ctx, "POST", OPENCODE_ENDPOINT, bytes.NewReader(body))
		if err != nil {
			lastErr = err
			continue
		}
		httpReq.Header.Set("Content-Type", "application/json")
		resp, err := httpClient.Do(httpReq)
		if err != nil {
			lastErr = fmt.Errorf("attempt %d: %w", i+1, err)
			continue
		}
		if resp.StatusCode == http.StatusOK {
			return resp, nil
		}
		resp.Body.Close()
		lastErr = fmt.Errorf("attempt %d: status %d", i+1, resp.StatusCode)
	}
	return nil, fmt.Errorf("upstream failed after %d retries: %v", maxRetries, lastErr)
}

func handleChat(c *gin.Context) {
	requests++

	var req ChatRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		errCount++
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if len(req.Messages) == 0 {
		errCount++
		c.JSON(http.StatusBadRequest, gin.H{"error": "no messages"})
		return
	}

	body := map[string]interface{}{
		"model":    OPENCODE_MODEL,
		"messages": req.Messages,
		"stream":   req.Stream,
	}
	if req.Temperature > 0 {
		body["temperature"] = req.Temperature
	}
	if req.MaxTokens > 0 {
		body["max_tokens"] = req.MaxTokens
	}

	bodyBytes, _ := json.Marshal(body)
	resp, err := callWithRetry(c.Request.Context(), bodyBytes)
	if err == nil {
		defer resp.Body.Close()
		if req.Stream {
			proxyStream(c, resp)
			return
		}
		var upstream map[string]interface{}
		if err := json.NewDecoder(resp.Body).Decode(&upstream); err == nil {
			if choices, ok := upstream["choices"].([]interface{}); ok && len(choices) > 0 {
				if choice, ok := choices[0].(map[string]interface{}); ok {
					if message, ok := choice["message"].(map[string]interface{}); ok {
						if content, ok := message["content"].(string); ok {
							writeReply(c, content)
							return
						}
					}
				}
			}
		}
	}

	// Offline fallback — mock brain, zero network, critical ops always work
	errCount++
	lastMsg := ""
	for i := len(req.Messages) - 1; i >= 0; i-- {
		if c, ok := req.Messages[i].Content.(string); ok {
			lastMsg = c
			break
		}
	}
	writeReply(c, mockResponse(lastMsg))
}

func writeReply(c *gin.Context, content string) {
	c.JSON(http.StatusOK, gin.H{
		"id":      "chatcmpl-" + uuid.New().String()[:8],
		"object":  "chat.completion",
		"created": time.Now().Unix(),
		"model":   OPENCODE_MODEL,
		"choices": []gin.H{{
			"index":        0,
			"message":      gin.H{"role": "assistant", "content": content},
			"finish_reason": "stop",
		}},
	})
}

func mockResponse(msg string) string {
	m := strings.ToLower(strings.TrimSpace(msg))
	switch {
	// Trading critical
	case strings.Contains(m, "start") && (strings.Contains(m, "trade") || strings.Contains(m, "bot")):
		return "Trading bot started. Monitoring markets with ultra-low latency pipeline."
	case strings.Contains(m, "stop") && (strings.Contains(m, "trade") || strings.Contains(m, "bot")):
		return "Trading bot stopped. All positions will be maintained, no new entries."
	case strings.Contains(m, "trade") && strings.Contains(m, "status"):
		return "Trading status: active. 0 open positions. Daily P&L: $0.00. System healthy."
	case strings.Contains(m, "emergency") || strings.Contains(m, "kill"):
		return "⚠️ EMERGENCY KILL available — POST /emergency/kill with {\"confirmation\":\"KILL\"} to halt all systems."

	// Market data
	case strings.Contains(m, "price") || strings.Contains(m, "btc") || strings.Contains(m, "eth"):
		return "Market data unavailable offline. Check back when connected, or use MT5 terminal directly."

	// System
	case strings.Contains(m, "health") || strings.Contains(m, "status") || m == "":
		return "Friday is running in offline fallback mode. Core systems healthy. Trading safety active. Reconnect for full AI capabilities."

	// Companion
	case strings.Contains(m, "hello") || strings.Contains(m, "hi") || strings.Contains(m, "hey"):
		return "At your service, sir. I'm in offline fallback — critical systems still operational."

	default:
		responses := []string{
			"Running in offline fallback mode. Reconnect for full AI, core systems still functional.",
			"Network limited — basic operations available. Connect to the internet for my full brain.",
			"Offline mode active. Financial safety systems operational. Reconnect for deep AI capabilities.",
		}
		return responses[rand.Intn(len(responses))]
	}
}

func proxyStream(c *gin.Context, resp *http.Response) {
	c.Header("Content-Type", "text/event-stream")
	c.Header("Cache-Control", "no-cache")
	c.Header("Connection", "keep-alive")
	c.Header("X-Accel-Buffering", "no")

	reader := bufio.NewReader(resp.Body)
	for {
		line, err := reader.ReadBytes('\n')
		if err != nil {
			break
		}
		c.Writer.Write(line)
		c.Writer.Flush()
		if bytes.HasPrefix(line, []byte("data: [DONE]")) {
			break
		}
	}
}

func handleTranscribe(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"text": "[voice: use local Whisper]"})
}

func handleSpeech(c *gin.Context) {
	c.JSON(http.StatusNotImplemented, gin.H{"error": "TTS: use Edge TTS locally"})
}

func getEnv(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}
