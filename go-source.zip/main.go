package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"runtime"
	"sync"
	"syscall"
	"time"

	"github.com/friday-prototype/friday-go/friday"
	"github.com/friday-prototype/friday-go/friday/trading"
	"github.com/friday-prototype/friday-go/pkg/db"
	"github.com/gin-gonic/gin"
)

var (
	version      = "2.0.0"
	buildDate    = "unknown"
	apiURL       = getEnv("API_URL", "https://api.deepinfra.com/v1/openai")
	apiKey       = getEnv("API_KEY", "")
	apiModel     = getEnv("API_MODEL", "deepseek-ai/DeepSeek-V4-Pro")
	apiFreeModel = getEnv("API_FREE_MODEL", "deepseek-ai/DeepSeek-V4-Flash")
)

func getEnv(k, fallback string) string {
	if v := os.Getenv(k); v != "" { return v }
	return fallback
}

func main() {
	log.SetFlags(log.LstdFlags | log.Lshortfile)
	log.Printf("Friday v%s (build %s) starting...", version, buildDate)

	cfg := friday.LoadConfig()

	// Initialize SQLite database
	dbPath := filepath.Join(friday.ProjectRoot, "data", "friday.db")
	if err := db.Init(dbPath); err != nil {
		log.Fatalf("Failed to initialize database: %v", err)
	}
	defer db.Close()
	log.Printf("Database ready: %s", dbPath)

	// Initialize embeddings (semantic memory) — non-fatal if Ollama not running
	ollamaURL := getEnv("OLLAMA_URL", "http://localhost:11434")
	embedModel := getEnv("EMBED_MODEL", "nomic-embed-text")
	if err := friday.InitEmbeddings(ollamaURL, embedModel); err != nil {
		log.Printf("embeddings init: %v (semantic search disabled)", err)
	} else {
		log.Printf("Embeddings ready: model=%s", embedModel)
		// Backfill existing facts in background
		go func() {
			time.Sleep(5 * time.Second)
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
			defer cancel()
			count, err := friday.BackfillEmbeddings(ctx, 32)
			if err != nil {
				log.Printf("embedding backfill: %v", err)
			} else if count > 0 {
				log.Printf("Embedded %d existing facts", count)
			}
		}()
	}

	engine := trading.NewEngine(cfg)
	var engineWg sync.WaitGroup
	engineWg.Add(1)
	go func() {
		defer engineWg.Done()
		if err := engine.Start(); err != nil && err != http.ErrServerClosed {
			log.Printf("Trading engine error: %v", err)
		}
	}()
	time.Sleep(500 * time.Millisecond)

	server := friday.NewServer(cfg)
	server.Router().POST("/v1/chat/completions", bridgeHandler)
	mountWebUI(server)
	server.Listen()

	addr := fmt.Sprintf("http://localhost:%d", cfg.Port)
	log.Printf("Server ready at %s", addr)
	openBrowser(addr)

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.Println("Shutting down...")
	server.Shutdown()
	engineStopCtx, engineStopCancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer engineStopCancel()
	engine.Stop(engineStopCtx)
	engineWg.Wait()
	log.Println("Stopped")
}

func openBrowser(url string) {
	switch runtime.GOOS {
	case "windows":
		exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
	case "darwin":
		exec.Command("open", url).Start()
	default:
		exec.Command("xdg-open", url).Start()
	}
}

// ── LLM Bridge ──
//
// Transparent passthrough: we forward the incoming JSON body verbatim to the
// upstream OpenAI-compatible API (DeepInfra/DeepSeek), only swapping the model
// name. This preserves ALL fields the orchestrator relies on for agentic
// function calling: tools, tool_choice, and the tool_calls / tool_call_id
// fields carried inside messages. The previous typed bridgeReq struct silently
// dropped everything except {model, messages, stream}, which is why native
// function calling never worked end-to-end.

type bridgeChoice struct {
	Index   int             `json:"index"`
	Message json.RawMessage `json:"message"`
}
type bridgeResp struct {
	ID      string         `json:"id"`
	Object  string         `json:"object"`
	Created int64          `json:"created"`
	Model   string         `json:"model"`
	Choices []bridgeChoice `json:"choices"`
}

func bridgeHandler(c *gin.Context) {
	body, _ := io.ReadAll(c.Request.Body)
	if len(body) == 0 {
		c.JSON(400, gin.H{"error": "empty body"})
		return
	}
	// Parse into a map so we can swap "model" without touching anything else
	// (tools, tool_choice, tool_calls, tool_call_id, messages with
	// function-call roles, temperature, max_tokens, response_format, ...).
	var payload map[string]any
	if err := json.Unmarshal(body, &payload); err != nil {
		c.JSON(400, gin.H{"error": "invalid request: " + err.Error()})
		return
	}
	// If the client asked for streaming, honor it by streaming the upstream
	// response back as-is. The current orchestrator always uses Stream=false,
	// but support it for ChatHandler's non-agent streaming path.
	streamRequested, _ := payload["stream"].(bool)

	models := []struct {
		name  string
		total time.Duration
	}{
		{apiFreeModel, 25 * time.Second},
		{apiModel, 90 * time.Second},
		{"deepseek-ai/DeepSeek-V3-0324", 90 * time.Second},
	}
	client := &http.Client{Timeout: 100 * time.Second}
	for _, m := range models {
		payload["model"] = m.name
		upBody, _ := json.Marshal(payload)
		upReq, err := http.NewRequestWithContext(c.Request.Context(), "POST", apiURL+"/chat/completions", bytes.NewReader(upBody))
		if err != nil {
			continue
		}
		upReq.Header.Set("Content-Type", "application/json")
		upReq.Header.Set("Authorization", "Bearer "+apiKey)
		if streamRequested {
			upReq.Header.Set("Accept", "text/event-stream")
		}
		client.Timeout = m.total
		resp, err := client.Do(upReq)
		if err != nil {
			continue
		}
		upBody, _ = io.ReadAll(resp.Body)
		resp.Body.Close()
		if resp.StatusCode != 200 {
			continue
		}
		var chat bridgeResp
		if json.Unmarshal(upBody, &chat) == nil && len(chat.Choices) > 0 && len(chat.Choices[0].Message) > 0 {
			c.Data(200, "application/json", upBody)
			return
		}
	}
	c.JSON(200, bridgeResp{ID: "fallback", Object: "chat.completion",
		Created: time.Now().Unix(), Model: apiModel,
		Choices: []bridgeChoice{{Index: 0, Message: rawMsg("All models busy. Try again.")}}})
}

func rawMsg(content string) json.RawMessage {
	b, _ := json.Marshal(map[string]string{"role": "assistant", "content": content})
	return b
}

func mountWebUI(s *friday.Server) {
	for _, dir := range []string{
		filepath.Join(friday.ProjectRoot, "webui"),
		filepath.Join(friday.ProjectRoot, "..", "webui"),
		filepath.Join(friday.ProjectRoot, "..", "interface"),
	} {
		if _, err := os.Stat(filepath.Join(dir, "index.html")); err == nil {
			log.Printf("UI: serving from %s", dir)
			s.Router().Static("/static", dir)
			s.Router().GET("/", func(c *gin.Context) { c.File(filepath.Join(dir, "index.html")) })
			s.Router().GET("/control-center", func(c *gin.Context) { c.File(filepath.Join(dir, "cc.html")) })
			return
		}
	}
}
