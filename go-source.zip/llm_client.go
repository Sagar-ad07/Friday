package friday

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
)

// LLMClient connects to the LLM Bridge (port 9001) with Ollama fallback
type LLMClient struct {
	baseURL    string
	httpClient *http.Client
	cache      *SemanticCache
	router     *ModelRouter
	mu         sync.RWMutex
}

func NewLLMClient(baseURL string) *LLMClient {
	return &LLMClient{
		baseURL: baseURL,
		httpClient: &http.Client{
			Timeout: 120 * time.Second,
			Transport: &http.Transport{
				MaxIdleConns:        100,
				MaxIdleConnsPerHost: 100,
				IdleConnTimeout:     90 * time.Second,
			},
		},
		cache:  NewSemanticCache(2000, 30*time.Minute),
		router: NewModelRouter(),
	}
}

// Chat calls the LLM Bridge, falls back to Ollama if bridge is down
func (c *LLMClient) Chat(ctx context.Context, messages []Message, role Role) (*ChatCompletionResponse, error) {
	req := ChatRequest{
		Model:    "meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo",
		Messages: messages,
	}

	// Check cache
	cacheKey := c.cache.Key(&req)
	if cached, _, ok := c.cache.Get(cacheKey); ok {
		cached.ID = fmt.Sprintf("chatcmpl-%s", uuid.New().String()[:8])
		cached.Created = time.Now().Unix()
		return cached, nil
	}

	// Try LLM Bridge first
	body, _ := json.Marshal(req)
	httpReq, err := http.NewRequestWithContext(ctx, "POST", c.baseURL+"/v1/chat/completions", bytes.NewReader(body))
	if err == nil {
		httpReq.Header.Set("Content-Type", "application/json")
		resp, err := c.httpClient.Do(httpReq)
		if err == nil {
			if resp.StatusCode == http.StatusOK {
				var result ChatCompletionResponse
				if json.NewDecoder(resp.Body).Decode(&result) == nil {
					resp.Body.Close()
					if len(result.Choices) > 0 && result.Choices[0].Message.Content != "" {
						c.cache.Set(cacheKey, &result, "llm-bridge")
						return &result, nil
					}
				} else {
					resp.Body.Close()
				}
			} else {
				resp.Body.Close()
			}
		}
	}

	// Bridge failed — fallback to local Ollama models
	log.Printf("LLM Bridge unavailable, falling back to local models")
	result, err := c.router.Chat(ctx, messages)
	if err != nil {
		return nil, fmt.Errorf("all models failed: %v", err)
	}

	c.cache.Set(cacheKey, result, "ollama")
	return result, nil
}

// ChatWithTools runs an OpenAI-style chat completion with native function-calling
// (the "tools" param). Used by the agentic loop. Cache is intentionally bypassed
// — agentic calls differ across runs (different tool results, different
// message histories) and the cache key doesn't include the tools field.
//
// Pass tools=nil to force a final synthesis call (no tool promotions will be
// offered to the model, so it must reply with content).
func (c *LLMClient) ChatWithTools(ctx context.Context, messages []Message, tools []ToolDef) (*ChatCompletionResponse, error) {
	req := ChatRequest{
		Model:    "agent", // bridge overrides this; pick something stable
		Messages: messages,
		Tools:    tools,
	}
	if len(tools) > 0 {
		req.ToolChoice = "auto"
	}

	body, _ := json.Marshal(req)
	httpReq, err := http.NewRequestWithContext(ctx, "POST", c.baseURL+"/v1/chat/completions", bytes.NewReader(body))
	if err != nil {
		return nil, fmt.Errorf("build request: %w", err)
	}
	httpReq.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(httpReq)
	if err != nil {
		// Fall back to the local router if the bridge is unreachable.
		log.Printf("ChatWithTools: bridge unreachable (%v), trying local models", err)
		return c.router.ChatWithTools(ctx, messages, tools)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		rb, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("bridge status %d: %.400s", resp.StatusCode, string(rb))
	}

	var result ChatCompletionResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, fmt.Errorf("decode: %w", err)
	}
	if len(result.Choices) == 0 {
		return nil, fmt.Errorf("no choices in response")
	}
	// Bridge returns "All models busy" as HTTP 200 when all its backends fail.
	// This is a bridge fallback, not a real answer — fall through to the router.
	if strings.Contains(result.Choices[0].Message.Content, "All models busy") {
		log.Printf("ChatWithTools: bridge returned fallback, trying local models")
		return c.router.ChatWithTools(ctx, messages, tools)
	}
	return &result, nil
}

// StreamChat for SSE streaming
func (c *LLMClient) StreamChat(ctx context.Context, messages []Message, role Role) (<-chan *ChatCompletionResponse, error) {
	req := ChatRequest{
		Model:    "friday",
		Messages: messages,
		Stream:   true,
	}

	body, _ := json.Marshal(req)
	httpReq, err := http.NewRequestWithContext(ctx, "POST", c.baseURL+"/v1/chat/completions", bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("Accept", "text/event-stream")

	resp, err := c.httpClient.Do(httpReq)
	if err != nil {
		return nil, err
	}

	ch := make(chan *ChatCompletionResponse, 10)

	go func() {
		defer close(ch)
		defer resp.Body.Close()

		decoder := json.NewDecoder(resp.Body)
		for {
			var chunk ChatCompletionResponse
			if err := decoder.Decode(&chunk); err != nil {
				if err == io.EOF {
					return
				}
				log.Printf("Stream decode error: %v", err)
				return
			}
			select {
			case ch <- &chunk:
			case <-ctx.Done():
				return
			}
		}
	}()

	return ch, nil
}

// Health check
func (c *LLMClient) Health(ctx context.Context) error {
	// Check external API directly (avoids recursive /health loop on self)
	req, _ := http.NewRequestWithContext(ctx, "GET", "https://api.deepinfra.com/v1/openai/models", nil)
	resp, err := c.httpClient.Do(req)
	if err != nil {
		return err
	}
	resp.Body.Close()
	// Any response (200, 401, etc.) means the API is reachable
	return nil
}

// Models list
func (c *LLMClient) Models(ctx context.Context) ([]ModelInfo, error) {
	httpReq, _ := http.NewRequestWithContext(ctx, "GET", c.baseURL+"/v1/models", nil)
	resp, err := c.httpClient.Do(httpReq)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result ModelsResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	return result.Data, nil
}