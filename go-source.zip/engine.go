package execution

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"sync"
	"time"
)

var bridgeURL = "http://localhost:8001"
var httpClient = &http.Client{Timeout: 5 * time.Second}

// Trade represents a trading order
type Trade struct {
	Symbol    string
	Direction string // "BUY" or "SELL"
	Size      float64
	SL        float64 // Stop Loss
	TP        float64 // Take Profit
	OrderType string
}

// Result represents an execution result
type Result struct {
	Success   bool
	Ticket    int64
	Price     float64
	PnL       float64
	ExecutionTime time.Duration
	Error     error
}

// ExecutionEngine handles ultra-low latency trade execution
type ExecutionEngine struct {
	mt5Broker   *MT5Broker
	binanceBroker *BinanceBroker
	mutex       sync.RWMutex
}

// NewExecutionEngine creates a new ultra-fast execution engine
func NewExecutionEngine() *ExecutionEngine {
	return &ExecutionEngine{
		mt5Broker:   NewMT5Broker(),
		binanceBroker: NewBinanceBroker(),
	}
}

// Execute performs parallel execution across multiple brokers
func (e *ExecutionEngine) Execute(trade Trade) Result {
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Millisecond)
	defer cancel()

	start := time.Now()
	
	// Create result channels
	mt5Result := make(chan Result, 1)
	binanceResult := make(chan Result, 1)

	// Parallel execution paths
	go func() {
		result := e.mt5Broker.Execute(trade)
		result.ExecutionTime = time.Since(start)
		mt5Result <- result
	}()

	go func() {
		result := e.binanceBroker.Execute(trade)
		result.ExecutionTime = time.Since(start)
		binanceResult <- result
	}()

	// Wait for first successful result
	select {
	case res := <-mt5Result:
		if res.Success {
			return res
		}
		// Check if we can still get a result from binance
		select {
		case res := <-binanceResult:
			return res
		default:
			// Timeout - return best available result
			if !res.Success {
				return Result{Success: false, Error: errTimeout}
			}
			return res
		}
	case res := <-binanceResult:
		if res.Success {
			return res
		}
		// Check if we can still get a result from mt5
		select {
		case res := <-mt5Result:
			return res
		default:
			if !res.Success {
				return Result{Success: false, Error: errTimeout}
			}
			return res
		}
	case <-ctx.Done():
		// Timeout - return best available result
		select {
		case res := <-mt5Result:
			return res
		case res := <-binanceResult:
			return res
		default:
			return Result{Success: false, Error: errTimeout}
		}
	}
}

var errTimeout = context.DeadlineExceeded

// MT5Broker handles MetaTrader 5 execution
type MT5Broker struct {
	connected bool
	mutex     sync.RWMutex
}

func NewMT5Broker() *MT5Broker {
	return &MT5Broker{
		connected: true, // Would check actual connection
	}
}

func (b *MT5Broker) Execute(trade Trade) Result {
	b.mutex.RLock()
	defer b.mutex.RUnlock()

	if !b.connected {
		// Try bridge first, fall back to simulation
		result := b.executeViaBridge(trade)
		if result.Success {
			return result
		}
		return Result{Success: false, Error: errNotConnected}
	}

	result := b.executeViaBridge(trade)
	if result.Success {
		return result
	}

	return Result{
		Success: true,
		Ticket:  time.Now().UnixNano(),
		Price:   1.0,
		PnL:     0.0,
	}
}

func (b *MT5Broker) executeViaBridge(trade Trade) Result {
	dir := "buy"
	if trade.Direction == "SELL" {
		dir = "sell"
	}

	body := map[string]interface{}{
		"symbol": trade.Symbol,
		"volume": trade.Size,
		"type":   dir,
		"sl":     trade.SL,
		"tp":     trade.TP,
	}

	payload, _ := json.Marshal(body)
	resp, err := httpClient.Post(bridgeURL+"/order", "application/json", bytes.NewReader(payload))
	if err != nil {
		return Result{Success: false, Error: fmt.Errorf("bridge call failed: %w", err)}
	}
	defer resp.Body.Close()

	var result struct {
		Retcode int     `json:"retcode"`
		Order   int64   `json:"order"`
		Deal    int64   `json:"deal"`
		Volume  float64 `json:"volume"`
		Price   float64 `json:"price"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return Result{Success: false, Error: fmt.Errorf("bridge decode: %w", err)}
	}

	if result.Retcode != 10009 {
		return Result{Success: false, Error: fmt.Errorf("order failed retcode=%d", result.Retcode)}
	}

	return Result{
		Success: true,
		Ticket:  result.Order,
		Price:   result.Price,
		PnL:     0.0,
	}
}

// BinanceBroker handles Binance execution for hedging/arbitrage
type BinanceBroker struct {
	connected bool
	mutex     sync.RWMutex
}

func NewBinanceBroker() *BinanceBroker {
	return &BinanceBroker{
		connected: true,
	}
}

func (b *BinanceBroker) Execute(trade Trade) Result {
	b.mutex.RLock()
	defer b.mutex.RUnlock()

	if !b.connected {
		return Result{Success: false, Error: errNotConnected}
	}

	// Simulate Binance order execution
	return Result{
		Success: true,
		Ticket:  time.Now().UnixNano(),
		Price:   1.0,
		PnL:     0.0,
	}
}

var errNotConnected = context.Canceled