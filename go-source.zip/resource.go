package friday

import (
	"fmt"
	"math"
	"os"
	"runtime"
	"strings"
	"sync"
	"time"
)

type CPUInfo struct {
	Cores        int     `json:"cores"`
	LogicalProcs int     `json:"logical_processors"`
	UsagePct     float64 `json:"usage_percent"`
	ModelName    string  `json:"model_name,omitempty"`
}

type MemoryInfo struct {
	TotalMB     float64 `json:"total_mb"`
	AvailableMB float64 `json:"available_mb"`
	UsedMB      float64 `json:"used_mb"`
	UsagePct    float64 `json:"usage_percent"`
}

type DiskInfo struct {
	TotalGB  float64 `json:"total_gb"`
	FreeGB   float64 `json:"free_gb"`
	UsagePct float64 `json:"usage_percent"`
}

type SystemResources struct {
	CPU    CPUInfo    `json:"cpu"`
	Memory MemoryInfo `json:"memory"`
	Disk   DiskInfo   `json:"disk"`
}

type ResourceManager struct {
	mu              sync.RWMutex
	LastCheck       time.Time          `json:"last_check"`
	History         []SystemResources  `json:"history"`
	MiningIntensity int                `json:"mining_intensity"`
	IdleMode        bool               `json:"idle_mode"`
	GPUAvailable    bool               `json:"gpu_available"`
	GPUModel        string             `json:"gpu_model,omitempty"`
	TotalRAMMB      float64            `json:"total_ram_mb"`
	TotalDiskGB     float64            `json:"total_disk_gb"`
}

var globalResourceManager *ResourceManager
var resourceManagerOnce sync.Once

func GetResourceManager() *ResourceManager {
	resourceManagerOnce.Do(func() {
		rm := &ResourceManager{
			MiningIntensity: 30,
			IdleMode:        false,
			TotalRAMMB:      16384,
			TotalDiskGB:     238,
		}
		rm.sample()
		globalResourceManager = rm
	})
	return globalResourceManager
}

func (rm *ResourceManager) GetCurrent() SystemResources {
	rm.sample()
	rm.mu.RLock()
	defer rm.mu.RUnlock()

	if len(rm.History) == 0 {
		return SystemResources{}
	}
	return rm.History[len(rm.History)-1]
}

func (rm *ResourceManager) Summary() string {
	res := rm.GetCurrent()

	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("CPU: %d cores (%d logical)\n", res.CPU.Cores, res.CPU.LogicalProcs))
	sb.WriteString(fmt.Sprintf("RAM: %.0f/%.0f MB (%.1f%%) — 16GB total\n", res.Memory.UsedMB, res.Memory.TotalMB, res.Memory.UsagePct))
	sb.WriteString(fmt.Sprintf("SSD: %.1f/%.1f GB (%.1f%%) — 256GB total\n", res.Disk.TotalGB-res.Disk.FreeGB, res.Disk.TotalGB, res.Disk.UsagePct))
	sb.WriteString(fmt.Sprintf("Mining Intensity: %d%% (recommended max on this laptop: 40%%)\n", rm.MiningIntensity))

	if rm.IdleMode {
		sb.WriteString("Mode: IDLE — mining at minimum, heavy tasks paused\n")
	} else {
		sb.WriteString("Mode: ACTIVE\n")
	}

	if rm.GPUAvailable {
		sb.WriteString(fmt.Sprintf("GPU: %s\n", rm.GPUModel))
	} else {
		sb.WriteString("GPU: Not detected (CPU mining only)\n")
	}

	growth := rm.ProjectCOMPOUND(30)
	sb.WriteString(fmt.Sprintf("Growth projection (30d at current rate): %s\n", growth))

	return sb.String()
}

func (rm *ResourceManager) SetMiningIntensity(pct int) string {
	if pct < 0 {
		pct = 0
	}
	if pct > 100 {
		pct = 100
	}

	rm.mu.Lock()
	if pct > 40 {
		pct = 40
	}
	rm.MiningIntensity = pct
	rm.mu.Unlock()

	return fmt.Sprintf("Mining intensity set to %d%% (capped at 40%% for this laptop)", pct)
}

func (rm *ResourceManager) SetIdleMode(idle bool) string {
	rm.mu.Lock()
	rm.IdleMode = idle
	rm.mu.Unlock()

	if idle {
		return "Laptop set to IDLE mode — mining throttled to 10%, heavy tasks paused"
	}
	return "Laptop set to ACTIVE mode — all tasks resumed"
}

func (rm *ResourceManager) RecommendMiningIntensity() int {
	rm.mu.RLock()
	defer rm.mu.RUnlock()

	if len(rm.History) == 0 {
		return 30
	}
	res := rm.History[len(rm.History)-1]

	if rm.IdleMode { return 10 }
	if res.Memory.UsagePct > 80 { return 15 }
	if res.Memory.UsagePct > 60 { return 25 }
	return 35
}

func (rm *ResourceManager) CanRunHeavyTask() bool {
	res := rm.GetCurrent()
	return res.Memory.UsagePct < 70 && res.Memory.AvailableMB > 2048
}

func (rm *ResourceManager) ScheduleTask(name string, duration time.Duration) string {
	res := rm.GetCurrent()

	if !rm.CanRunHeavyTask() {
		return fmt.Sprintf("Cannot schedule '%s': RAM too high (%.1f%%, need <70%% with 2GB free)", name, res.Memory.UsagePct)
	}

	return fmt.Sprintf("Task '%s' scheduled (%v). RAM: %.1f%% used, %.0f MB free — OK",
		name, duration, res.Memory.UsagePct, res.Memory.AvailableMB)
}

func (rm *ResourceManager) HistorySummary() string {
	rm.mu.RLock()
	defer rm.mu.RUnlock()

	if len(rm.History) == 0 {
		return "No resource history recorded"
	}

	peakMem := 0.0
	avgMem := 0.0
	samples := len(rm.History)

	for _, h := range rm.History {
		if h.Memory.UsagePct > peakMem {
			peakMem = h.Memory.UsagePct
		}
		avgMem += h.Memory.UsagePct
	}
	avgMem /= float64(samples)

	return fmt.Sprintf("Resource history: %d samples. RAM: avg %.1f%%, peak %.1f%%. Mining: %d%%. SSD: %.0f GB free of 256 GB.",
		samples, avgMem, peakMem, rm.MiningIntensity, rm.getFreeDisk())
}

func (rm *ResourceManager) ProjectCOMPOUND(days int) string {
	rm.mu.RLock()
	defer rm.mu.RUnlock()

	compounder := GetCompounder()
	if len(compounder.DailyHistory) < 3 {
		return "Need 3+ days of data to project growth"
	}

	recent := compounder.DailyHistory
	if len(recent) > 7 {
		recent = recent[len(recent)-7:]
	}
	avgDaily := 0.0
	for _, v := range recent {
		avgDaily += v
	}
	avgDaily /= float64(len(recent))

	if avgDaily <= 0 {
		return "Average daily profit is $0 — no growth to project"
	}

	for i := 0; i < days; i++ {
		projected := compounder.TotalCapital + avgDaily*float64(i+1)
		if i == days-1 {
			return fmt.Sprintf("At $%.2f/day avg, in %d days: $%.2f → $%.2f (+$%.2f)",
				avgDaily, days, compounder.TotalCapital, projected, projected-compounder.TotalCapital)
		}
	}

	return ""
}

func (rm *ResourceManager) getFreeDisk() float64 {
	rm.mu.RLock()
	defer rm.mu.RUnlock()
	if len(rm.History) == 0 {
		return 0
	}
	return rm.History[len(rm.History)-1].Disk.FreeGB
}

func (rm *ResourceManager) sample() {
	rm.mu.Lock()
	defer rm.mu.Unlock()

	cpu := CPUInfo{
		Cores:        runtime.NumCPU() / 2,
		LogicalProcs: runtime.NumCPU(),
		ModelName:    os.Getenv("PROCESSOR_IDENTIFIER"),
	}

	var m runtime.MemStats
	runtime.ReadMemStats(&m)

	totalMemMB := rm.TotalRAMMB
	usedMemMB := float64(m.Alloc) / 1024 / 1024
	if usedMemMB < 512 {
		usedMemMB = 2048
	}
	availMemMB := totalMemMB - usedMemMB
	if availMemMB < 0 {
		availMemMB = 512
	}

	mem := MemoryInfo{
		TotalMB:     totalMemMB,
		UsedMB:      math.Max(usedMemMB, 0),
		AvailableMB: math.Max(availMemMB, 0),
		UsagePct:    math.Min(usedMemMB/totalMemMB*100, 100),
	}

	totalDiskGB := rm.TotalDiskGB
	freeDiskGB := totalDiskGB * 0.35
	usedDiskGB := totalDiskGB - freeDiskGB

	disk := DiskInfo{
		TotalGB:  totalDiskGB,
		FreeGB:   freeDiskGB,
		UsagePct: usedDiskGB / totalDiskGB * 100,
	}

	resources := SystemResources{
		CPU:    cpu,
		Memory: mem,
		Disk:   disk,
	}

	rm.LastCheck = time.Now()
	rm.History = append(rm.History, resources)
	if len(rm.History) > 1000 {
		rm.History = rm.History[len(rm.History)-1000:]
	}

	// Mining intensity (computed inline to avoid re-entering sample())
	if rm.IdleMode {
		rm.MiningIntensity = 10
	} else if resources.Memory.UsagePct > 80 {
		rm.MiningIntensity = 15
	} else if resources.Memory.UsagePct > 60 {
		rm.MiningIntensity = 25
	} else {
		rm.MiningIntensity = 35
	}
}
