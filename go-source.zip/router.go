package friday

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/google/uuid"
)

type ModelProvider struct {
	Name     string
	URL      string // base URL like http://localhost:11434
	Model    string // model name to use
	Timeout  time.Duration
	IsOllama bool   // true = uses /api/chat, false = uses /v1/chat/completions
	APIKey   string // optional Bearer token for cloud APIs
}

type ModelRouter struct {
	providers []ModelProvider
	httpClient *http.Client
}

func NewModelRouter() *ModelRouter {
	return &ModelRouter{
		providers: []ModelProvider{
			{
				Name:    "deepseek-v3",
				URL:     "http://localhost:9001",
				Model:   "deepseek-v4-flash-free",
				Timeout: 30 * time.Second,
				IsOllama: false,
			},
		{
			Name:    "qwen2.5-7b",
			URL:     "http://localhost:11434",
			Model:   "qwen2.5:7b",
			Timeout: 60 * time.Second,
			IsOllama: true,
		},
		{
			Name:    "qwen2.5-1.5b",
			URL:     "http://localhost:11434",
			Model:   "qwen2.5:1.5b",
			Timeout: 30 * time.Second,
			IsOllama: true,
		},
		{
			Name:    "deepseek-api",
			URL:     "https://api.deepseek.com/v1",
			Model:   "deepseek-chat",
			Timeout: 60 * time.Second,
			IsOllama: false,
			APIKey:  os.Getenv("DEEPSEEK_API_KEY"),
		},
		},
		httpClient: &http.Client{Timeout: 120 * time.Second},
	}
}

func (r *ModelRouter) Chat(ctx context.Context, messages []Message) (*ChatCompletionResponse, error) {
	lastErr := "all providers failed"
	for _, p := range r.providers {
		req := ChatRequest{
			Model:    p.Model,
			Messages: messages,
			Stream:   false,
		}

		var resp *http.Response
		var err error
		body, _ := json.Marshal(req)

		if p.IsOllama {
			// Ollama uses /api/chat with different format
			var oReq struct {
				Model    string    `json:"model"`
				Messages []Message `json:"messages"`
				Stream   bool      `json:"stream"`
			}
			oReq.Model = p.Model
			oReq.Messages = messages
			oReq.Stream = false
			body, _ = json.Marshal(oReq)

			ctx2, cancel := context.WithTimeout(ctx, p.Timeout)
			httpReq, _ := http.NewRequestWithContext(ctx2, "POST", p.URL+"/api/chat", bytes.NewReader(body))
			httpReq.Header.Set("Content-Type", "application/json")
			resp, err = r.httpClient.Do(httpReq)
			cancel()
		} else {
			ctx2, cancel := context.WithTimeout(ctx, p.Timeout)
			httpReq, _ := http.NewRequestWithContext(ctx2, "POST", p.URL+"/v1/chat/completions", bytes.NewReader(body))
			httpReq.Header.Set("Content-Type", "application/json")
			if p.APIKey != "" {
				httpReq.Header.Set("Authorization", "Bearer "+p.APIKey)
			}
			resp, err = r.httpClient.Do(httpReq)
			cancel()
		}

		if err != nil {
			log.Printf("router: %s unreachable (%v), trying next", p.Name, err)
			lastErr = fmt.Sprintf("%s: %v", p.Name, err)
			continue
		}

		respBody, _ := io.ReadAll(resp.Body)
		resp.Body.Close()

		if resp.StatusCode != 200 {
			log.Printf("router: %s returned %d, trying next", p.Name, resp.StatusCode)
			lastErr = fmt.Sprintf("%s: status %d", p.Name, resp.StatusCode)
			continue
		}

		if p.IsOllama {
			// Parse Ollama response format -> ChatCompletionResponse
			var oResp struct {
				Model     string  `json:"model"`
				CreatedAt string  `json:"created_at"`
				Message   Message `json:"message"`
				Done      bool    `json:"done"`
			}
			if err := json.Unmarshal(respBody, &oResp); err != nil {
				log.Printf("router: %s parse error (%v), trying next", p.Name, err)
				lastErr = fmt.Sprintf("%s: parse %v", p.Name, err)
				continue
			}
			if oResp.Message.Content == "" {
				log.Printf("router: %s empty response, trying next", p.Name)
				lastErr = fmt.Sprintf("%s: empty", p.Name)
				continue
			}
			result := &ChatCompletionResponse{
				ID:      fmt.Sprintf("chatcmpl-%s", uuid.New().String()[:8]),
				Object:  "chat.completion",
				Created: time.Now().Unix(),
				Model:   p.Model,
				Choices: []Choice{{
					Index: 0,
					Message: Message{
						Role:    "assistant",
						Content: oResp.Message.Content,
					},
					FinishReason: "stop",
				}},
			}
			log.Printf("router: %s answered (%.200s)", p.Name, oResp.Message.Content)
			return result, nil
		}

		// Bridge /api format is already ChatCompletionResponse
		var result ChatCompletionResponse
		if err := json.Unmarshal(respBody, &result); err != nil {
			log.Printf("router: %s parse error (%v), trying next", p.Name, err)
			lastErr = fmt.Sprintf("%s: parse %v", p.Name, err)
			continue
		}
		if len(result.Choices) == 0 || result.Choices[0].Message.Content == "" {
			log.Printf("router: %s empty response, trying next", p.Name)
			lastErr = fmt.Sprintf("%s: empty", p.Name)
			continue
		}
		log.Printf("router: %s answered (%.200s)", p.Name, result.Choices[0].Message.Content)
		return &result, nil
	}

	return nil, fmt.Errorf("%s", lastErr)
}

// TaskType classifies what kind of work the model needs to do
type TaskType string

const (
	TaskChat       TaskType = "chat"        // General conversation
	TaskCode       TaskType = "code"        // Code generation/analysis
	TaskVision     TaskType = "vision"      // Image analysis
	TaskFast       TaskType = "fast"        // Quick simple responses
	TaskReasoning  TaskType = "reasoning"   // Complex multi-step reasoning
)

// RouteByTask returns the best provider for a given task type.
// This allows the orchestrator to pick the right model for the job.
func (r *ModelRouter) RouteByTask(task TaskType) *ModelProvider {
	if len(r.providers) == 0 {
		return nil
	}

	// Task → preferred provider name mapping
	preferences := map[TaskType]string{
		TaskChat:      "deepseek-v3",
		TaskCode:      "deepseek-v3",
		TaskVision:    "gemini",
		TaskFast:      "qwen2.5-1.5b",
		TaskReasoning: "deepseek-v3",
	}

	preferred := preferences[task]
	for i := range r.providers {
		if r.providers[i].Name == preferred {
			return &r.providers[i]
		}
	}

	// Fallback to first provider
	return &r.providers[0]
}

// ChatWithTask routes to the best model for the task type
func (r *ModelRouter) ChatWithTask(ctx context.Context, messages []Message, task TaskType) (*ChatCompletionResponse, error) {
	provider := r.RouteByTask(task)
	if provider == nil {
		return r.Chat(ctx, messages)
	}

	log.Printf("[ROUTER] task=%s → provider=%s model=%s", task, provider.Name, provider.Model)

	// Try the preferred provider first, then fall back to all
	req := ChatRequest{
		Model:    provider.Model,
		Messages: messages,
		Stream:   false,
	}

	body, _ := json.Marshal(req)
	ctx2, cancel := context.WithTimeout(ctx, provider.Timeout)
	defer cancel()

	var httpReq *http.Request
	var err error

	if provider.IsOllama {
		var oReq struct {
			Model    string    `json:"model"`
			Messages []Message `json:"messages"`
			Stream   bool      `json:"stream"`
		}
		oReq.Model = provider.Model
		oReq.Messages = messages
		oReq.Stream = false
		body, _ = json.Marshal(oReq)
		httpReq, err = http.NewRequestWithContext(ctx2, "POST", provider.URL+"/api/chat", bytes.NewReader(body))
	} else {
		httpReq, err = http.NewRequestWithContext(ctx2, "POST", provider.URL+"/v1/chat/completions", bytes.NewReader(body))
	}

	if err != nil {
		return r.Chat(ctx, messages) // fallback to sequential try-all
	}
	httpReq.Header.Set("Content-Type", "application/json")
	if provider.APIKey != "" {
		httpReq.Header.Set("Authorization", "Bearer "+provider.APIKey)
	}

	resp, err := r.httpClient.Do(httpReq)
	if err != nil {
		log.Printf("[ROUTER] preferred provider %s failed (%v), falling back", provider.Name, err)
		return r.Chat(ctx, messages)
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)
	if resp.StatusCode != 200 {
		log.Printf("[ROUTER] preferred provider %s returned %d, falling back", provider.Name, resp.StatusCode)
		return r.Chat(ctx, messages)
	}

	if provider.IsOllama {
		var oResp struct {
			Model     string  `json:"model"`
			CreatedAt string  `json:"created_at"`
			Message   Message `json:"message"`
			Done      bool    `json:"done"`
		}
		if err := json.Unmarshal(respBody, &oResp); err != nil || oResp.Message.Content == "" {
			return r.Chat(ctx, messages)
		}
		return &ChatCompletionResponse{
			ID:      fmt.Sprintf("chatcmpl-%s", uuid.New().String()[:8]),
			Object:  "chat.completion",
			Created: time.Now().Unix(),
			Model:   provider.Model,
			Choices: []Choice{{
				Index: 0,
				Message: Message{
					Role:    "assistant",
					Content: oResp.Message.Content,
				},
				FinishReason: "stop",
			}},
		}, nil
	}

	var result ChatCompletionResponse
	if err := json.Unmarshal(respBody, &result); err != nil || len(result.Choices) == 0 {
		return r.Chat(ctx, messages)
	}
	return &result, nil
}

// ChatWithTools sends messages + tool definitions to the best available
// provider that supports function calling. Falls back through all providers.
// Ollama providers use /api/chat with tools field (0.3+), others use /v1/chat/completions.
func (r *ModelRouter) ChatWithTools(ctx context.Context, messages []Message, tools []ToolDef) (*ChatCompletionResponse, error) {
	lastErr := "all providers failed"
	for _, p := range r.providers {
		reqMap := map[string]any{
			"model":    p.Model,
			"messages": messages,
			"stream":   false,
		}
		if len(tools) > 0 {
			reqMap["tools"] = tools
			reqMap["tool_choice"] = "auto"
		}
		body, _ := json.Marshal(reqMap)

		ctx2, cancel := context.WithTimeout(ctx, p.Timeout)
		var httpReq *http.Request
		if p.IsOllama {
			httpReq, _ = http.NewRequestWithContext(ctx2, "POST", p.URL+"/api/chat", bytes.NewReader(body))
		} else {
			httpReq, _ = http.NewRequestWithContext(ctx2, "POST", p.URL+"/v1/chat/completions", bytes.NewReader(body))
		}
		httpReq.Header.Set("Content-Type", "application/json")
		if p.APIKey != "" {
			httpReq.Header.Set("Authorization", "Bearer "+p.APIKey)
		}

		resp, err := r.httpClient.Do(httpReq)
		cancel()
		if err != nil {
			log.Printf("[ROUTER-TOOLS] %s unreachable (%v), trying next", p.Name, err)
			lastErr = fmt.Sprintf("%s: %v", p.Name, err)
			continue
		}
		respBody, _ := io.ReadAll(resp.Body)
		resp.Body.Close()
		if resp.StatusCode != 200 {
			log.Printf("[ROUTER-TOOLS] %s returned %d, trying next", p.Name, resp.StatusCode)
			lastErr = fmt.Sprintf("%s: status %d", p.Name, resp.StatusCode)
			continue
		}

		if p.IsOllama {
			var oResp struct {
				Message struct {
					Role      string     `json:"role"`
					Content   string     `json:"content"`
					ToolCalls []ToolCall `json:"tool_calls"`
				} `json:"message"`
			}
			if err := json.Unmarshal(respBody, &oResp); err != nil {
				log.Printf("[ROUTER-TOOLS] %s parse error (%v), trying next", p.Name, err)
				continue
			}
			result := &ChatCompletionResponse{
				ID:      fmt.Sprintf("chatcmpl-%s", uuid.New().String()[:8]),
				Object:  "chat.completion",
				Created: time.Now().Unix(),
				Model:   p.Model,
				Choices: []Choice{{
					Index: 0,
					Message: Message{
						Role:      oResp.Message.Role,
						Content:   oResp.Message.Content,
						ToolCalls: oResp.Message.ToolCalls,
					},
					FinishReason: "stop",
				}},
			}
			log.Printf("[ROUTER-TOOLS] %s answered (content=%d tool_calls=%d)", p.Name, len(oResp.Message.Content), len(oResp.Message.ToolCalls))
			return result, nil
		}

		var result ChatCompletionResponse
		if err := json.Unmarshal(respBody, &result); err != nil {
			log.Printf("[ROUTER-TOOLS] %s parse error (%v), trying next", p.Name, err)
			continue
		}
		if len(result.Choices) == 0 {
			continue
		}
		log.Printf("[ROUTER-TOOLS] %s answered (content=%d tool_calls=%d)", p.Name, len(result.Choices[0].Message.Content), len(result.Choices[0].Message.ToolCalls))
		return &result, nil
	}

	return nil, fmt.Errorf("%s", lastErr)
}

// ClassifyTask determines the task type from the user's message
func ClassifyTask(input string) TaskType {
	lower := strings.ToLower(input)

	// Vision: image-related
	if strings.Contains(lower, "image") || strings.Contains(lower, "picture") ||
		strings.Contains(lower, "photo") || strings.Contains(lower, "analyze this") {
		return TaskVision
	}

	// Code: programming-related
	if strings.Contains(lower, "code") || strings.Contains(lower, "function") ||
		strings.Contains(lower, "script") || strings.Contains(lower, "debug") ||
		strings.Contains(lower, "python") || strings.Contains(lower, "program") {
		return TaskCode
	}

	// Fast: short simple questions
	if len(input) < 50 && (strings.Contains(lower, "time") ||
		strings.Contains(lower, "status") || strings.Contains(lower, "hello") ||
		strings.Contains(lower, "hi ") || lower == "hi" || lower == "hey") {
		return TaskFast
	}

	// Action verbs that need tools - never route locally
	actionVerbs := []string{"check ", "show ", "get ", "find ", "tell me about",
		"what is the", "how is the", "look ", "pull ", "run ", "start ", "stop ",
		"buy ", "sell ", "trade ", "generate ", "search ", "lookup "}
	for _, v := range actionVerbs {
		if strings.HasPrefix(lower, v) || strings.Contains(lower, " "+v) {
			return TaskReasoning
		}
	}

	// Reasoning: complex multi-step
	if strings.Contains(lower, "analyze") || strings.Contains(lower, "compare") ||
		strings.Contains(lower, "strategy") || strings.Contains(lower, "calculate") ||
		strings.Contains(lower, "plan") || strings.Contains(lower, "explain why") {
		return TaskReasoning
	}

	return TaskChat
}
