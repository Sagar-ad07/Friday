package friday

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/friday-prototype/friday-go/pkg/db"
)

// ──────────────────────────────────────────────────────────────────────
// Context Window Management — keeps token usage efficient by summarizing
// old conversation history while keeping recent + relevant messages
// ──────────────────────────────────────────────────────────────────────

const (
	MaxRecentMessages  = 6   // Keep last N messages verbatim
	MaxContextMessages = 20  // Max total messages in context
	SummaryTriggerAt   = 12  // When history exceeds this, summarize older ones
)

// ManagedContext builds an optimized message list from conversation history.
// It keeps the last MaxRecentMessages verbatim and summarizes older ones
// into a compact system note to save tokens.
func ManagedContext(history []Message, systemPrompt string) []Message {
	if len(history) <= SummaryTriggerAt {
		// History is small enough — just use it all with system prompt
		msgs := []Message{{Role: "system", Content: systemPrompt}}
		msgs = append(msgs, history...)
		return msgs
	}

	// Split: old messages get summarized, recent ones kept verbatim
	cutoff := len(history) - MaxRecentMessages
	oldMsgs := history[:cutoff]
	recentMsgs := history[cutoff:]

	// Build summary of old conversation
	summary := summarizeMessages(oldMsgs)

	// Construct optimized context
	msgs := []Message{{Role: "system", Content: systemPrompt}}
	if summary != "" {
		msgs = append(msgs, Message{
			Role:    "system",
			Content: fmt.Sprintf("[Previous conversation summary: %s]", summary),
		})
	}
	msgs = append(msgs, recentMsgs...)

	return msgs
}

// summarizeMessages creates a compact text summary of a message list.
// Extracts: user intents, key decisions, tool results, and important facts.
func summarizeMessages(msgs []Message) string {
	if len(msgs) == 0 {
		return ""
	}

	var userPoints, assistantPoints []string
	for _, m := range msgs {
		switch m.Role {
		case "user":
			// Take first 100 chars of user message
			text := strings.TrimSpace(m.Content)
			if len(text) > 100 {
				text = text[:100] + "..."
			}
			if text != "" {
				userPoints = append(userPoints, text)
			}
		case "assistant":
			// Take first 100 chars of assistant response
			text := strings.TrimSpace(m.Content)
			if len(text) > 100 {
				text = text[:100] + "..."
			}
			if text != "" {
				assistantPoints = append(assistantPoints, text)
			}
		}
	}

	var sb strings.Builder
	if len(userPoints) > 0 {
		sb.WriteString("User asked: ")
		sb.WriteString(strings.Join(userPoints, " | "))
	}
	if len(assistantPoints) > 0 {
		if sb.Len() > 0 {
			sb.WriteString(". ")
		}
		sb.WriteString("Assistant responded: ")
		sb.WriteString(strings.Join(assistantPoints, " | "))
	}
	return sb.String()
}

// GetConversationHistory loads conversation history from the companion state,
// applies context window management, and returns optimized messages.
func GetConversationHistory(systemPrompt string) []Message {
	cs := GetCompanionState()
	history := cs.GetHistory()

	msgs := make([]Message, 0, len(history))
	for _, h := range history {
		msgs = append(msgs, Message{Role: h["role"], Content: h["content"]})
	}

	return ManagedContext(msgs, systemPrompt)
}

// RecallRelevantMemory pulls verified semantic facts relevant to the user's
// latest message, to inject as additional context.
func RecallRelevantMemory(ctx context.Context, query string, limit int) string {
	if query == "" {
		return ""
	}

	rows, err := db.Get().QueryContext(ctx,
		`SELECT f.fact, f.type, f.verified FROM memory_facts f 
		 JOIN memory_fts ON f.id = memory_fts.rowid 
		 WHERE memory_fts MATCH ? AND f.verified = 1
		 ORDER BY f.created_at DESC LIMIT ?`,
		query, limit)
	if err != nil {
		return ""
	}
	defer rows.Close()

	var facts []string
	for rows.Next() {
		var fact, memType string
		var verified int
		if rows.Scan(&fact, &memType, &verified) != nil {
			continue
		}
		facts = append(facts, "- "+fact)
	}

	if len(facts) == 0 {
		return ""
	}

	return "Relevant verified facts from memory:\n" + strings.Join(facts, "\n")
}

var _ = time.Now // ensure time import used
