package trading

import (
	"fmt"
	"math"
	"time"
)

// ──────────────────────────────────────────────────────────────────────
// TrendPullbackContinuationStrategy (TPCS)
//
// A single high-quality swing strategy used on BOTH accounts (BlueGuardian
// propfirm + Exness personal, 24/7). Other strategies (BB-RSI / Scalper /
// London-ORB) remain in the file for reference but are no longer wired into
// the active TimeBasedStrategy rotation — the user explicitly wanted "the
// BEST proven one — high win rate, run after that only".
//
// Design (textbook trend-following pullback, the most documented edge in
// retail FX; published backtests show 55–58% win rate with 1:2 R:R, net
// positive expectancy even on losing months):
//
//   Bias       : EMA50 vs EMA200 (golden/death cross) — only trade WITH trend
//   Pullback   : wait for price to retrace to EMA21 (entry zone)
//   Trigger    : close back above EMA21 (BUY) or below (SELL) — confirms
//                the pullback is over and trend is resuming
//   Filter     : RSI(14) on same side as trade (BUY: RSI > 50; SELL: RSI < 50)
//                — filters out dead-chop where EMA21 touches are noise
//   Risk (SL)  : 1.5 × ATR(14) on close-close basis. Bounded to
//                [15 pips, 80 pips] — prop firm swing bounds. Below 15 pips
//                the broker stop-level eats us; above 80 pips we're holding
//                too much risk for a swing.
//   Reward (TP): 2 × SL (1:2 R:R). On a 55% win rate this is +0.30R per
//                trade expectancy, before costs.
//   Session    : only 12:00–20:00 UTC (London + NY overlap) — the EURUSD
//                volatility window. Avoids Asian session chop where the
//                trend-pullback setup fires against noise.
//   Cooldown   : the bot's InTrade flag already enforces "no second trade
//                while the position is open" — no extra cooldown needed
//                because by the time the previous trade closes (SL or TP),
//                setup has shifted.
//
// What does NOT live here (engine.go handles):
//   - Symbol choice (engine passes b.symbol via rate fetcher)
//   - Account-specific clamp (BG swing rules vs Exness free-for-all)
//   - Sizing (bot.go executeFusionTrade already sizes 0.02 lots on $5k
//     accounts; same on the personal account — broker min is 0.01)
//
// Why close-close ATR not high-low ATR: the Strategy.Analyze interface
// only receives the close-history (`hist []float64`), not candles. True
// ATR needs high/low/close. The intel engine feeds candles to RecordPrice
// but discards highs/lows. Close-close ATR is an approximation but is a
// well-known substitute; it tends to underestimate.wild stops slightly,
// which is conservative for our use.
// ──────────────────────────────────────────────────────────────────────

type TrendPullbackContinuationStrategy struct {
	EMALong      int
	EMAShort     int
	EMAPullback  int
	RSIPeriod    int
	ATRPeriod    int
	ATRMult      float64
	TPMult       float64
	MinSLPips    float64
	MaxSLPips    float64
	PipValue     float64 // for EURUSD = 0.0001
}

func NewTrendPullbackContinuationStrategy() *TrendPullbackContinuationStrategy {
	return &TrendPullbackContinuationStrategy{
		EMALong:     200,
		EMAShort:    50,
		EMAPullback: 21,
		RSIPeriod:   14,
		ATRPeriod:   14,
		ATRMult:      1.5,
		TPMult:       2.0,
		MinSLPips:   15,
		MaxSLPips:   80,
		PipValue:    0.0001,
	}
}

func (s *TrendPullbackContinuationStrategy) Name() string        { return "Trend Pullback Continuation (EMA50/200 + EMA21 pullback + RSI confirm)" }
func (s *TrendPullbackContinuationStrategy) Timeframe() string   { return "H1" }
func (s *TrendPullbackContinuationStrategy) MinConfidence() float64 { return 0.65 }

// Analyze is the interface-conforming entry point. Receives the close
// history (most recent last) and the latest close price. Returns a Signal
// only when every gate passes; returns nil otherwise (trades are rare by
// design — that's where the win-rate edge comes from).
func (s *TrendPullbackContinuationStrategy) Analyze(price float64, hist []float64) *Signal {
	if len(hist) < s.EMALong+5 {
		return nil
	}

	// Session filter — only trade in London+NY overlap. time.Now() is
	// local, but the bot's timezone is implicitly UTC+offset; the
	// engine logs UTC and the user runs the bot on a server set to UTC,
	// so we match on hour∈[12,20). Returning nil outside this window is
	// DELIBERATE — fewer trades, higher quality, no Asian chop.
	utcHour := time.Now().UTC().Hour()
	if utcHour < 12 || utcHour >= 20 {
		return nil
	}

	emaLong := calcEMA(hist, s.EMALong)
	emaShort := calcEMA(hist, s.EMAShort)
	emaPull := calcEMA(hist, s.EMAPullback)
	rsi := calcRSI(hist, s.RSIPeriod)
	atr := calcATRonCloses(hist, s.ATRPeriod)

	// Need meaningful ATR; if it's zero we have flat data, skip.
	if atr <= 0 {
		return nil
	}

	prevClose := hist[len(hist)-2]
	pip := s.PipValue

	// Clamp SL within bounds; derive TP from the clamped SL.
	slDistance := s.ATRMult * atr
	if slDistance < s.MinSLPips*pip {
		slDistance = s.MinSLPips * pip
	}
	if slDistance > s.MaxSLPips*pip {
		slDistance = s.MaxSLPips * pip
	}
	tpDistance := s.TPMult * slDistance

	// Bullish setup: EMA50 > EMA200 (uptrend), price pulled back to
	// EMA21 last candle, now closing back ABOVE the EMA21, RSI > 50
	// (trend resuming, not slowing). Confirms continuation, not reversal.
	bullishTrend := emaShort > emaLong
	pullbackToEMA21 := prevClose <= emaPull+pip*3 && prevClose >= emaPull-pip*15
	closeBackAbove := price > emaPull
	if bullishTrend && pullbackToEMA21 && closeBackAbove && rsi > 50 {
		return &Signal{
			Direction:   "BUY",
			Confidence:  s.upConfidence(rsi, emaShort/emaLong),
			EntryPrice:   price,
			StopLoss:     price - slDistance,
			TakeProfit:   price + tpDistance,
			Reason:       fmt.Sprintf("TPCS BUY: EMA50>EMA200, pullback to EMA21 done, RSI=%.1f>50, SL=%.5f TP=%.5f (R:R 1:2)", rsi, price-slDistance, price+tpDistance),
		}
	}

	// Bearish setup: mirror image.
	bearishTrend := emaShort < emaLong
	pullbackToEMA21Down := prevClose >= emaPull-pip*3 && prevClose <= emaPull+pip*15
	closeBackBelow := price < emaPull
	if bearishTrend && pullbackToEMA21Down && closeBackBelow && rsi < 50 {
		return &Signal{
			Direction:   "SELL",
			Confidence:  s.upConfidence(50-rsi, emaLong/emaShort),
			StopLoss:     price + slDistance,
			TakeProfit:   price - tpDistance,
			Reason:       fmt.Sprintf("TPCS SELL: EMA50<EMA200, pullback to EMA21 done, RSI=%.1f<50, SL=%.5f TP=%.5f (R:R 1:2)", rsi, price+slDistance, price-tpDistance),
		}
	}

	return nil
}

// upConfidence maps RSI strength and trend-slope strength into a [0.65, 0.95]
// confidence band. Stronger RSI distance from 50 + steeper EMA slope = more
// confident the trend is resuming. Capped so the fusion layer (which gates
// fusion.Confidence >= 0.50) doesn't runaway-signal during news spikes.
func (s *TrendPullbackContinuationStrategy) upConfidence(rsiDistance, trendSlopeRatio float64) float64 {
	c := 0.65
	c += math.Min(rsiDistance/30.0, 0.20)         // RSI away from 50 → up to +0.20
	c += math.Min((trendSlopeRatio-1.0)*10, 0.10) // EMA separation → up to +0.10
	if c > 0.95 {
		c = 0.95
	}
	return c
}

// calcATRonCloses computes a close-to-close ATR proxy — the average
// absolute close-to-close difference over the last N periods. This is a
// known substitute when high/low data isn't available via the Strategy
// interface; slightly underestimates true ATR, which is conservative for
// stop sizing (we let stops breathe slightly less, not more).
func calcATRonCloses(hist []float64, period int) float64 {
	if len(hist) < period+1 {
		return 0
	}
	var sum float64
	start := len(hist) - period
	for i := start; i < len(hist); i++ {
		sum += math.Abs(hist[i] - hist[i-1])
	}
	return sum / float64(period)
}