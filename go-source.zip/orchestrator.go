package orchestrator

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"sync"
	"time"

	"github.com/friday-prototype/friday-go/config"
	"github.com/friday-prototype/friday-go/execution"
	"github.com/friday-prototype/friday-go/friday"
	"github.com/friday-prototype/friday-go/miner"
	"github.com/friday-prototype/friday-go/safety"
	"github.com/friday-prototype/friday-go/trading"
	"github.com/gin-gonic/gin"
)

type BotManager struct {
	mu          sync.RWMutex
	ExnessBot   *trading.TradingBot
	BGBot       *trading.BlueGuardianBot
	XMRigMiner  *miner.XMRigMiner
}

type Orchestrator struct {
	cfg           *config.Config
	botManager    *BotManager
	execEngine    *execution.ExecutionEngine
	guardians     *safety.TradingGuardians
	mu            sync.RWMutex
	activeStreams map[string]chan []byte
	companion     *friday.CompanionState
}

func NewOrchestratorWithManager(bm *BotManager) *Orchestrator {
	cfg := config.GetConfig()
	companion := friday.GetCompanionState()

	return &Orchestrator{
		cfg:           cfg,
		botManager:    bm,
		execEngine:    execution.NewExecutionEngine(),
		guardians:     safety.NewTradingGuardians(5000.0),
		activeStreams: make(map[string]chan []byte),
		companion:     companion,
	}
}

func (o *Orchestrator) ChatHandler(c *gin.Context) {
	var req struct {
		Model    string          `json:"model"`
		Messages json.RawMessage `json:"messages"`
		Stream   bool            `json:"stream"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	response := o.processChat(req.Messages)
	c.JSON(http.StatusOK, gin.H{
		"id":      fmt.Sprintf("chatcmpl-%d", time.Now().UnixNano()),
		"object":  "chat.completion",
		"created": time.Now().Unix(),
		"model":   req.Model,
		"choices": []gin.H{
			{
				"index": 0,
				"message": gin.H{
					"role":    "assistant",
					"content": response,
				},
				"finish_reason": "stop",
			},
		},
		"usage": gin.H{
			"prompt_tokens":     0,
			"completion_tokens": 0,
			"total_tokens":      0,
		},
	})
}

func (o *Orchestrator) CommandHandler(c *gin.Context) {
	var req struct {
		Command string                 `json:"command"`
		Args    map[string]interface{} `json:"args"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	result := o.executeCommand(req.Command, req.Args)
	c.JSON(http.StatusOK, gin.H{"result": result})
}

func (o *Orchestrator) StreamHandler(c *gin.Context) {
	var req struct {
		Model    string          `json:"model"`
		Messages json.RawMessage `json:"messages"`
		Stream   bool            `json:"stream"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	streamID := fmt.Sprintf("stream-%d", time.Now().UnixNano())
	streamChan := make(chan []byte, 100)
	o.mu.Lock()
	o.activeStreams[streamID] = streamChan
	o.mu.Unlock()

	defer func() {
		o.mu.Lock()
		delete(o.activeStreams, streamID)
		close(streamChan)
		o.mu.Unlock()
	}()

	c.Header("Content-Type", "text/event-stream")
	c.Header("Cache-Control", "no-cache")
	c.Header("Connection", "keep-alive")
	c.Header("X-Accel-Buffering", "no")

	c.Stream(func(w io.Writer) bool {
		select {
		case data, ok := <-streamChan:
			if !ok {
				return false
			}
			_, err := w.Write(data)
			return err == nil
		case <-c.Request.Context().Done():
			return false
		}
	})
}

func (o *Orchestrator) VoiceHandler(c *gin.Context) {
	var req struct {
		Audio  string `json:"audio" binding:"required"`
		Format string `json:"format"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	transcription := o.transcribeAudio(req.Audio)
	response := o.processChat([]byte(fmt.Sprintf(`[{"role":"user","content":"%s"}]`, transcription)))
	audioResponse := o.synthesizeSpeech(response)

	c.JSON(http.StatusOK, gin.H{
		"transcription": transcription,
		"response":      response,
		"audio":         audioResponse,
	})
}

func (o *Orchestrator) processChat(messages json.RawMessage) string {
	var msgs []struct {
		Role    string `json:"role"`
		Content string `json:"content"`
	}
	json.Unmarshal(messages, &msgs)

	lastMsg := ""
	if len(msgs) > 0 {
		lastMsg = msgs[len(msgs)-1].Content
	}

	if lastMsg != "" {
		o.companion.RecordMessage("user", lastMsg)
	}

	switch {
	case contains(lastMsg, "exness", "mt5"):
		return o.handleExnessQuery()
	case contains(lastMsg, "blue guardian", "prop", "bg", "50k"):
		return o.handleBlueGuardianQuery()
	case contains(lastMsg, "miner", "xmrig", "monero", "mining"):
		return o.handleMinerQuery()
	case contains(lastMsg, "capability", "built", "what can you"):
		return o.handleCapabilitiesQuery()
	case contains(lastMsg, "trade", "buy", "sell", "position"):
		return o.handleTradingQuery(lastMsg)
	case contains(lastMsg, "status", "balance", "account"):
		return o.handleStatusQuery()
	case contains(lastMsg, "start", "stop", "bot"):
		return o.handleBotControl(lastMsg)
	default:
		return "Friday AI - all 3 bots active (Exness, Blue Guardian $50K, XMRig Miner). Ask about any bot, capabilities, or give trading commands."
	}
}

func (o *Orchestrator) executeCommand(cmd string, args map[string]interface{}) interface{} {
	switch cmd {
	case "exness_start":
		return o.botManager.ExnessBot.Start()
	case "exness_stop":
		o.botManager.ExnessBot.Stop()
		return "stopped"
	case "exness_status":
		return o.botManager.ExnessBot.GetStatus()
	case "bg_status":
		return o.botManager.BGBot.GetStatus()
	case "bg_can_trade":
		can, reason := o.botManager.BGBot.CanTrade()
		return map[string]interface{}{"can_trade": can, "reason": reason}
	case "bg_can_withdraw":
		can, reason := o.botManager.BGBot.CanWithdraw()
		return map[string]interface{}{"can_withdraw": can, "reason": reason}
	case "miner_start":
		return o.botManager.XMRigMiner.Start()
	case "miner_stop":
		return o.botManager.XMRigMiner.Stop()
	case "miner_status":
		return o.botManager.XMRigMiner.Status()
	case "friday_capabilities":
		return o.companion.AllCapabilities()
	case "trading_start":
		return o.botManager.ExnessBot.Start()
	case "trading_stop":
		o.botManager.ExnessBot.Stop()
		return "stopped"
	case "trading_status":
		return o.botManager.ExnessBot.GetStatus()
	case "execute_trade":
		return o.executeTrade(args)
	case "safety_check":
		return o.guardians.GetLimits()
	case "market_data":
		return o.getMarketData(args)
	default:
		return fmt.Sprintf("Unknown command: %s. Available: exness_start/stop/status, bg_status/can_trade/can_withdraw, miner_start/stop/status, friday_capabilities", cmd)
	}
}

func (o *Orchestrator) handleExnessQuery() string {
	status := o.botManager.ExnessBot.GetStatus()
	return fmt.Sprintf("Exness Bot: Running=%v, InTrade=%v, DailyPnL=$%.2f, TotalPnL=$%.2f, TradesToday=%d. Strategy: Time-based (BB-RSI/ORB/Scalper). Endpoint: /exness/status",
		status["running"], status["in_trade"], status["daily_pnl"], status["total_pnl"], status["trades_today"])
}

func (o *Orchestrator) handleBlueGuardianQuery() string {
	status := o.botManager.BGBot.GetStatus()
	canTrade, _ := o.botManager.BGBot.CanTrade()
	canWithdraw, _ := o.botManager.BGBot.CanWithdraw()
	return fmt.Sprintf("Blue Guardian $50K Bot: CanTrade=%v, CanWithdraw=%v, Drawdown=%.1f%%, Consistency=%.1f%%, TradingDays=%.0f, TotalPnL=$%.2f. Rules: 15%% consistency, 4%% daily loss, 8%% max drawdown, 3 min trading days.",
		canTrade, canWithdraw, status["drawdown_pct"], status["consistency_pct"], status["trading_days"], status["total_pnl"])
}

func (o *Orchestrator) handleMinerQuery() string {
	s := o.botManager.XMRigMiner.Status()
	return fmt.Sprintf("XMRig Miner: Status=%s, HashRate=%.1f H/s, Shares=%d, Accepted=%d, Estimated=$%.4f. Coin: Monero (XMR). Passive earnings, no investment needed.",
		s["status"], s["hash_rate_hs"], s["shares_total"], s["shares_accepted"], s["estimated_total"])
}

func (o *Orchestrator) handleCapabilitiesQuery() string {
	caps := o.companion.AllCapabilities()
	result := "Friday has built and manages these capabilities:\n"
	for name, info := range caps {
		if m, ok := info.(map[string]interface{}); ok {
			if desc, ok := m["description"].(string); ok {
				result += fmt.Sprintf("- %s: %s\n", name, desc)
			}
		}
	}
	result += "Ask about any bot for detailed status."
	return result
}

func (o *Orchestrator) handleTradingQuery(query string) string {
	status := o.botManager.ExnessBot.GetStatus()
	return fmt.Sprintf("Trading Bot: Running=%v, InTrade=%v, DailyPnL=%.2f, TotalPnL=%.2f, TradesToday=%d",
		status["running"], status["in_trade"], status["daily_pnl"], status["total_pnl"], status["trades_today"])
}

func (o *Orchestrator) handleStatusQuery() string {
	cap := o.companion.AllCapabilities()
	return fmt.Sprintf("Friday has %d capabilities built. 3 bots active: Exness (EURUSD MT5), Blue Guardian ($50K prop), XMRig Miner (passive Monero). All managed via Friday unified server on port %d.", len(cap), o.cfg.Port)
}

func (o *Orchestrator) handleBotControl(query string) string {
	if contains(query, "start") {
		if err := o.botManager.ExnessBot.Start(); err != nil {
			return fmt.Sprintf("Failed to start: %v", err)
		}
		return "Exness trading bot started"
	}
	if contains(query, "stop") {
		o.botManager.ExnessBot.Stop()
		return "Exness trading bot stopped"
	}
	return "Use 'start bot' or 'stop bot'"
}

func (o *Orchestrator) executeTrade(args map[string]interface{}) interface{} {
	symbol := getString(args, "symbol", "EURUSD")
	direction := getString(args, "direction", "BUY")
	size := getFloat(args, "size", 0.01)
	sl := getFloat(args, "sl", 0)
	tp := getFloat(args, "tp", 0)

	trade := execution.Trade{
		Symbol:    symbol,
		Direction: direction,
		Size:      size,
		SL:        sl,
		TP:        tp,
	}

	result := o.execEngine.Execute(trade)
	return gin.H{
		"success": result.Success,
		"ticket":  result.Ticket,
		"price":   result.Price,
		"error":   result.Error,
	}
}

func (o *Orchestrator) getMarketData(args map[string]interface{}) interface{} {
	symbol := getString(args, "symbol", "EURUSD")
	price := 1.0850 + float64(time.Now().UnixNano()%100)/100000.0
	return gin.H{"symbol": symbol, "bid": price, "ask": price + 0.0001, "time": time.Now().Unix()}
}

func (o *Orchestrator) transcribeAudio(audio string) string {
	return "Voice transcription placeholder"
}

func (o *Orchestrator) synthesizeSpeech(text string) string {
	return "base64_audio_placeholder"
}

func contains(s string, keywords ...string) bool {
	for _, k := range keywords {
		if len(s) >= len(k) {
			for i := 0; i <= len(s)-len(k); i++ {
				if s[i:i+len(k)] == k {
					return true
				}
			}
		}
	}
	return false
}

func getString(m map[string]interface{}, key, def string) string {
	if v, ok := m[key]; ok {
		if s, ok := v.(string); ok {
			return s
		}
	}
	return def
}

func getFloat(m map[string]interface{}, key string, def float64) float64 {
	if v, ok := m[key]; ok {
		switch val := v.(type) {
		case float64:
			return val
		case float32:
			return float64(val)
		case int:
			return float64(val)
		}
	}
	return def
}

func (o *Orchestrator) startStreamProcessing(ctx context.Context) {
	ticker := time.NewTicker(100 * time.Millisecond)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			o.mu.RLock()
			for _, ch := range o.activeStreams {
				select {
				case ch <- []byte("data: {\"heartbeat\":true}\n\n"):
				default:
				}
			}
			o.mu.RUnlock()
		}
	}
}
